/**
 * The MIT License (MIT)
 * Copyright (c) 2025 Advanced Micro Devices, Inc. All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 * and associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/**
 * @file wire.h
 * @brief On‑wire protocol for vrtd (V80 Runtime Daemon).
 *
 * Transport:
 *  - UNIX domain sockets (AF_UNIX, SOCK_SEQPACKET). Messages are record‑oriented.
 *  - File descriptors may be sent out‑of‑band using SCM_RIGHTS.
 *
 * Framing:
 *  - Each message = { header, body }.
 *  - Total size (header + body) MUST be <= VRTD_MSG_MAX_SIZE.
 *
 * Sequencing:
 *  - Requests carry a client‑chosen @ref vrtd_req_header::seqno that is echoed
 *    unmodified by the server in @ref vrtd_resp_header::seqno.
 *
 * Versioning/Extensibility:
 *  - Unknown opcodes result in VRTD_RET_BAD_REQUEST.
 *  - New fields may be added at the *end* of messages; older peers must ignore
 *    trailing bytes up to @ref vrtd_resp_header::size.
 *
 * Security:
 *  - Server enforces permissions; failures surface as VRTD_RET_AUTH_ERROR.
 */

#ifndef VRTD_WIRE_H
#define VRTD_WIRE_H

#include <stdint.h>

#include <slash/uapi/slash_interface.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Maximum total size (header + body) for any vrtd message in bytes. */
#define VRTD_MSG_MAX_SIZE 4096

/**
 * @brief Operations the client can request from the server.
 * @note Unknown/unsupported opcodes yield VRTD_RET_BAD_REQUEST.
 */
enum vrtd_opcode {
    /** Query the number of SLASH devices. */
    VRTD_REQ_GET_NUM_DEVICES,

    /** Query basic information about a device. */
    VRTD_REQ_GET_DEVICE_INFO,

    /** Query metadata about a device BAR. */
    VRTD_REQ_GET_BAR_INFO,

    /** Obtain a device BAR file descriptor via SCM_RIGHTS. */
    VRTD_REQ_GET_BAR_FD,

    /** Query QDMA capabilities of a device. */
    VRTD_REQ_QDMA_GET_INFO,

    /** Create a QDMA qpair on a device. */
    VRTD_REQ_QDMA_QPAIR_ADD,

    /** Apply an operation (start/stop/del) to a QDMA qpair. */
    VRTD_REQ_QDMA_QPAIR_OP,

    /** Obtain a read/write file descriptor for a QDMA qpair. */
    VRTD_REQ_QDMA_QPAIR_GET_FD,

    /** Perform a design writer transfer by passing an input fd via SCM_RIGHTS. */
    VRTD_REQ_DESIGN_WRITE,

    /** Get or set a clock rate for the service/user region. */
    VRTD_REQ_CLOCK_OP,

    /** Open a buffer (allocation + QDMA qpair) and return a qpair fd. */
    VRTD_REQ_BUFFER_OPEN,

    /** Close a buffer (release allocation + QDMA qpair). */
    VRTD_REQ_BUFFER_CLOSE,

    /** Query a device index by PCI BDF. */
    VRTD_REQ_GET_DEVICE_BY_BDF,

    /** Perform a PCIe hotplug operation for a device. */
    VRTD_REQ_DEVICE_HOTPLUG_OP,

    /** Query sensor information for a device via AMI. */
    VRTD_REQ_GET_SENSOR_INFO,

    /** Open a raw buffer (QDMA qpair at caller-specified device address, bypassing allocator). */
    VRTD_REQ_BUFFER_OPEN_RAW,

    /** Program a PDI into cfgmem via AMI and reset into the programmed partition. */
    VRTD_REQ_CFGMEM_PROGRAM,

    /** Start a cfgmem program job and return a job identifier immediately. */
    VRTD_REQ_CFGMEM_PROGRAM_START,

    /** Query progress for a cfgmem program job. */
    VRTD_REQ_CFGMEM_PROGRAM_STATUS,

    /** Set vrtd's in-memory shell/JTAG state for a device. */
    VRTD_REQ_SET_SHELL_STATE,

    /** Allocate host memory a kernel's AXI master can reach; returns an fd via SCM_RIGHTS. */
    VRTD_REQ_HOST_BUFFER_ALLOC,

    /** Query the UUID of the design loaded on a device and how many clients hold it. */
    VRTD_REQ_GET_DESIGN_INFO,

    /** Make vrtd forget the design loaded on a device (an image was loaded outside vrtd). */
    VRTD_REQ_FORGET_DESIGN,
};

/**
 * @brief Return codes for vrtd operations.
 *
 * @warning VRTD_RET_BAD_LIB_CALL and VRTD_RET_BAD_CONN are **client‑local**
 *          and are never returned by the server on the wire.
 */

enum vrtd_ret {
    VRTD_RET_OK,
    VRTD_RET_BAD_LIB_CALL, ///< Bad library call to libvrtd. This code will not be returned on the wire.
    VRTD_RET_BAD_CONN, ///< libvrtd could not connect to vrtd. This code will not be returned on the wire.
    VRTD_RET_BAD_REQUEST, ///< Malformed request.
    VRTD_RET_INVALID_ARGUMENT, ///< Invalid argument.
    VRTD_RET_NOEXIST, ///< Requested resource does not exist.
    VRTD_RET_INTERNAL_ERROR, ///< Internal error in the vrtd daemon. Check the vrtd log.
    VRTD_RET_AUTH_ERROR, ///< User does not have permission to execute request.
    VRTD_RET_BUSY, ///< Requested resource is busy.
    VRTD_RET_SHELL_LOCKED, ///< Device is JTAG-booted and will not be auto-reset for shell switching.
    VRTD_RET_DEVICE_UNHEALTHY, ///< The card must be reset before it can be programmed (AMC not ready, user clock cannot be parked, or a previous design write failed).
};

/**
 * @brief Allocation types for buffer requests.
 */
enum vrtd_alloc_type {
    VRTD_ALLOC_TYPE_DDR = 0,
    VRTD_ALLOC_TYPE_HBM = 1,
    VRTD_ALLOC_TYPE_HBM_VNOC = 2,
};

/**
 * @brief Direction for data transfers for allocated buffer.
 */
enum vrtd_alloc_dir {
    VRTD_ALLOC_DIR_BIDIRECTIONAL = 0,
    VRTD_ALLOC_DIR_HOST_TO_DEVICE = 1,
    VRTD_ALLOC_DIR_DEVICE_TO_HOST = 2,
};

#define VRTD_PCI_BDF_LEN 32

struct vrtd_pci_info {
    char bdf[VRTD_PCI_BDF_LEN];
    uint16_t vendor_id;
    uint16_t device_id;
    uint16_t subsystem_vendor_id;
    uint16_t subsystem_device_id;
} __attribute__((packed));

struct vrtd_req_header {
    uint16_t size; ///< Size of the request body (not including the header).
    uint16_t opcode; ///< See @ref vrtd_opcode.
    uint32_t seqno; ///< Sequence number (this will simply be echoed by the server in the response header).
} __attribute__((packed));

struct vrtd_resp_header {
    uint16_t size; ///< Size of the response body (not including the header).
    uint16_t ret; ///< See @ref vrtd_ret.
    uint32_t seqno; ///< Sequence number (this is simply echoed from the request header).
} __attribute__((packed));

/**
 * @brief Placeholder body to avoid empty-struct ABI pitfalls across C/C++.
 * @note Must be set to zero by clients; servers must ignore its value.
 */
struct vrtd_req_get_num_devices {
    uint8_t zero;
} __attribute__((packed));


struct vrtd_resp_get_num_devices {
    uint32_t num_devices; ///< Number of SLASH devices known to the server. They are identified by numbers in the range [0, n).
} __attribute__((packed));


struct vrtd_req_get_device_info {
    uint32_t dev_number; ///< The device for which to get info. An index in the range [0, n).
} __attribute__((packed));

struct vrtd_device_info {
    char name[128]; ///< The name of the device.
    struct vrtd_pci_info pci; ///< PCIe metadata (BDF and IDs).
    uint8_t shell_type; ///< Current shell state known by vrtd (enum vrtd_shell_type).
    uint8_t jtag;       ///< Non-zero if vrtd believes the device is JTAG-booted.
} __attribute__((packed));

struct vrtd_resp_get_device_info {
    struct vrtd_device_info info;
} __attribute__((packed));

struct vrtd_req_get_device_by_bdf {
    char bdf[VRTD_PCI_BDF_LEN]; ///< PCI BDF string (e.g., 0000:65:00.0)
} __attribute__((packed));

struct vrtd_resp_get_device_by_bdf {
    uint32_t dev_number; ///< Device index (0-based).
} __attribute__((packed));

struct vrtd_req_get_bar_info {
    uint32_t dev_number; ///< The device for which to get info. An index in the range [0, n).
    uint8_t bar_number; ///< The BAR for which to get info. An index in the range [0, 6).
} __attribute__((packed));

struct vrtd_resp_get_bar_info {
    struct slash_ioctl_bar_info bar_info; ///< The structure with BAR information.
} __attribute__((packed));

struct vrtd_req_get_bar_fd {
    uint32_t dev_number; ///< The device for who's BAR to get a file descriptor. An index in the range [0, n).
    uint8_t bar_number; ///< The BAR for which to get a file descriptor. An index in the range [0, 6).
} __attribute__((packed));

/**
 * @brief Response to VRTD_REQ_GET_BAR_FD.
 *
 * The BAR file descriptor is sent out-of-band via SCM_RIGHTS in the same
 * message and is present only when @ref vrtd_resp_header::ret == VRTD_RET_OK.
 */
/**
 * @brief Request to VRTD_REQ_HOST_BUFFER_ALLOC.
 *
 * Kernels reach host DRAM through the QDMA slave bridge, which addresses it by
 * bus address. The daemon owns the allocation so it outlives any single client
 * mapping, matching how BAR and qpair fds are handled.
 */
struct vrtd_req_host_buffer_alloc {
    uint32_t dev_number; ///< Device whose DMA mapping the allocation belongs to.
    uint64_t length;     ///< Requested size in bytes; rounded up to a page.
} __attribute__((packed));

/**
 * @brief Response to VRTD_REQ_HOST_BUFFER_ALLOC.
 *
 * The buffer file descriptor is sent out-of-band via SCM_RIGHTS in the same
 * message and is present only when @ref vrtd_resp_header::ret == VRTD_RET_OK.
 */
struct vrtd_resp_host_buffer_alloc {
    uint64_t len;         ///< Granted size after rounding; suitable for mmap.
    uint64_t dma_address; ///< Bus address the device masters to.
} __attribute__((packed));

struct vrtd_resp_get_bar_fd {
    uint64_t len; ///< Size of the BAR address space; suitable for mmap.
} __attribute__((packed));

/**
 * @brief Request QDMA capability information for a device.
 *
 * Complementary to @c slash_qdma_info; this wraps the libslash QDMA
 * info query and exposes it over the vrtd protocol.
 */
struct vrtd_req_qdma_get_info {
    uint32_t dev_number; ///< The device for which to get QDMA info. An index in the range [0, n).
} __attribute__((packed));

struct vrtd_resp_qdma_get_info {
    struct slash_qdma_info info; ///< QDMA capabilities for the device.
} __attribute__((packed));

/**
 * @brief Request creation of a QDMA qpair.
 *
 * The @c slash_qdma_qpair_add payload is passed through to the kernel
 * and the resulting qid is returned in the response.
 */
struct vrtd_req_qdma_qpair_add {
    uint32_t dev_number; ///< Device index (0-based).
    struct slash_qdma_qpair_add add; ///< Qpair creation parameters.
} __attribute__((packed));

struct vrtd_resp_qdma_qpair_add {
    struct slash_qdma_qpair_add add; ///< Echoed qpair parameters with qid filled in.
} __attribute__((packed));

/**
 * @brief Request an operation on an existing QDMA qpair.
 *
 * @ref op uses the same numeric values as @c SLASH_QDMA_QUEUE_OP_START and friends.
 */
struct vrtd_req_qdma_qpair_op {
    uint32_t dev_number; ///< Device index (0-based).
    uint32_t qid;        ///< Qpair identifier as returned by qpair_add.
    uint32_t op;         ///< One of SLASH_QDMA_QUEUE_OP_{START,STOP,DEL}.
} __attribute__((packed));

struct vrtd_resp_qdma_qpair_op {
    uint8_t zero; ///< Placeholder to avoid empty-struct ABI issues.
} __attribute__((packed));

/**
 * @brief Request a read/write file descriptor for a QDMA qpair.
 *
 * One or more qpair FDs are sent out-of-band via SCM_RIGHTS when
 * @ref vrtd_resp_header::ret == VRTD_RET_OK.  The response body reports the
 * number of descriptors attached.
 */
struct vrtd_req_qdma_qpair_get_fd {
    uint32_t dev_number; ///< Device index (0-based).
    uint32_t qid;        ///< Qpair identifier as returned by qpair_add.
    uint32_t flags;      ///< Only O_CLOEXEC is currently honored.
} __attribute__((packed));

struct vrtd_resp_qdma_qpair_get_fd {
    uint8_t zero; ///< Placeholder; all data is carried via SCM_RIGHTS.
} __attribute__((packed));

/**
 * @brief Request a buffer (allocation + QDMA qpair) and a qpair FD.
 *
 * The qpair FD is sent out-of-band via SCM_RIGHTS when
 * @ref vrtd_resp_header::ret == VRTD_RET_OK.
 */
struct vrtd_req_buffer_open {
    uint32_t dev_number; ///< Device index (0-based).
    uint32_t alloc_type; ///< One of enum vrtd_alloc_type.
    uint32_t alloc_dir;  ///< One of enum vrtd_alloc_dir.
    uint32_t mm_channel; ///< AXI-MM/NoC channel selection (enum vrtd_mm_channel).
    uint64_t alloc_arg;  ///< Allocation argument (HBM region index for HBM).
    uint64_t size;       ///< Requested size in bytes.
} __attribute__((packed));

struct vrtd_resp_buffer_open {
    uint64_t size; ///< Allocated size in bytes (rounded up to subregion).
    uint64_t phys_addr; ///< Device physical address of the allocation.
    /**
     * Number of QDMA queue pairs (AXI-MM/NoC channels) owned by the single
     * transfer FD sent via SCM_RIGHTS (1 or 2).  When two qpairs are bound
     * (an mm_channel == AUTO request), their qpair_index ordering is fixed:
     * index 0 is pinned to channel 0 and index 1 to channel 1, so the client
     * can apply the V80 placement policy deterministically.  Exactly one FD is
     * always sent regardless of this count.
     */
    uint32_t qpair_count;
} __attribute__((packed));

/**
 * @brief Request closing a buffer (release allocation + QDMA qpair).
 */
struct vrtd_req_buffer_close {
    uint32_t dev_number; ///< Device index (0-based).
    uint64_t phys_addr;  ///< Device physical address of the allocation.
    uint64_t size;       ///< Allocated size in bytes.
} __attribute__((packed));

struct vrtd_resp_buffer_close {
    uint8_t zero; ///< Placeholder to avoid empty-struct ABI issues.
} __attribute__((packed));

/**
 * @brief Request a raw buffer (QDMA qpair at caller-specified device address).
 *
 * Bypasses the allocator entirely — the caller is responsible for ensuring the
 * address is valid and not in use.  Requires the @c raw-mem-access permission.
 *
 * A single transfer FD is sent out-of-band via SCM_RIGHTS when
 * @ref vrtd_resp_header::ret == VRTD_RET_OK.  The response body reports how
 * many queue pairs (channels) that FD owns.
 */
struct vrtd_req_buffer_open_raw {
    uint32_t dev_number; ///< Device index (0-based).
    uint32_t alloc_dir;  ///< One of enum vrtd_alloc_dir.
    uint32_t mm_channel; ///< AXI-MM/NoC channel selection (enum vrtd_mm_channel).
    uint64_t phys_addr;  ///< Caller-specified device physical address (bypasses allocator).
    uint64_t size;       ///< Size in bytes.
} __attribute__((packed));

struct vrtd_resp_buffer_open_raw {
    /**
     * Number of QDMA queue pairs (channels) owned by the single transfer FD
     * sent via SCM_RIGHTS (1 or 2).  Same qpair_index-to-channel ordering as
     * @ref vrtd_resp_buffer_open.
     */
    uint32_t qpair_count;
} __attribute__((packed));

enum vrtd_shell_type {
    VRTD_SHELL_UNKNOWN = 0,
    VRTD_SHELL_SERVICE = 1,
    VRTD_SHELL_COMPUTE = 2,
};

/**
 * @brief Size of a design UUID in bytes.
 *
 * The linker stamps a random UUID into every vbin.  The all-zero UUID is the
 * null UUID: a design without an identity, or a loaded design vrtd does not
 * know.
 */
#define VRTD_DESIGN_UUID_LEN 16

/**
 * @brief Flags of a design write request.
 */
enum vrtd_design_write_flags {
    /** Write the design even when the device already holds it. */
    VRTD_DESIGN_WRITE_FORCE = 1 << 0,
    /** More PDIs of the same design follow in later requests. */
    VRTD_DESIGN_WRITE_MORE = 1 << 1,
};

/**
 * @brief Request a design writer transfer.
 *
 * The input file descriptor is sent out-of-band via SCM_RIGHTS.
 *
 * The daemon remembers the UUID of the design it wrote last.  A request that
 * carries the same non-null UUID is answered without writing, unless
 * VRTD_DESIGN_WRITE_FORCE is set, the device needs a reset, or the request
 * needs another shell.  The client whose request wrote the design, and every
 * client whose request was skipped, holds a reference on the design until it
 * disconnects.  A request that would replace a design another client holds
 * fails with VRTD_RET_BUSY, and so does a request that arrives while another
 * client's write is in flight, even of the same design: the daemon does not
 * queue it.  When the last holder disconnects the daemon parks the user clock;
 * the design stays loaded.
 *
 * A skipped request leaves the design as its holders left it: kernels keep
 * their state and the clock keeps its rate.  The response says how many
 * connections hold the design, so a client knows whether it is the only user
 * (and may set the clock) or shares a running design (and must leave it).
 *
 * The UUID is recorded once the transfer and the PF2 refresh completed; the
 * daemon does not check that the card applied the PDI.
 *
 * A design made of several PDIs is written with one request per PDI, all with
 * the same UUID and all but the last with VRTD_DESIGN_WRITE_MORE.  Only the
 * first request can be skipped; the client then skips the rest.
 *
 * The daemon rejects a request shorter than this struct with
 * VRTD_RET_BAD_REQUEST: daemon and clients must be upgraded together.
 */
struct vrtd_req_design_write {
    uint32_t dev_number; ///< Device index (0-based).
    uint8_t required_shell; ///< One of vrtd_shell_type.
    uint8_t flags; ///< Bitmask of vrtd_design_write_flags.
    uint8_t uuid[VRTD_DESIGN_UUID_LEN]; ///< UUID of the design; all-zero if it has none.
} __attribute__((packed));

struct vrtd_resp_design_write {
    uint8_t skipped; ///< Non-zero if the design was already loaded and nothing was written.
    uint32_t num_holders; ///< Connections that hold the design now, the requester included.
} __attribute__((packed));

/**
 * @brief Request that the daemon forget the design loaded on a device.
 *
 * For a client that changed the fabric without a design write, for example
 * by loading an image over JTAG.  The loaded UUID becomes unknown, so the
 * next design write is not skipped; a write in flight records nothing.
 * Holders keep their references.  Requires the design-write permission.
 */
struct vrtd_req_forget_design {
    uint32_t dev_number; ///< Device index (0-based).
} __attribute__((packed));

struct vrtd_resp_forget_design {
    uint8_t zero; ///< Placeholder to avoid empty-struct ABI issues.
} __attribute__((packed));

/**
 * @brief Request the loaded design of a device.
 */
struct vrtd_req_get_design_info {
    uint32_t dev_number; ///< Device index (0-based).
} __attribute__((packed));

struct vrtd_design_info {
    uint8_t uuid[VRTD_DESIGN_UUID_LEN]; ///< UUID of the loaded design; all-zero if unknown.
    uint32_t num_holders; ///< Number of client connections holding a reference on the design.
} __attribute__((packed));

struct vrtd_resp_get_design_info {
    struct vrtd_design_info info;
} __attribute__((packed));

/**
 * @brief Request cfgmem programming through AMI.
 *
 * The PDI file descriptor is sent out-of-band via SCM_RIGHTS.  On success, the
 * daemon programs @ref partition on @ref boot_device, selects that partition
 * for boot, and performs the vrtd-managed reset sequence.
 */
struct vrtd_req_cfgmem_program {
    uint32_t dev_number; ///< Device index (0-based).
    uint8_t boot_device; ///< AMI boot device selector (primary/secondary).
    uint8_t reserved[3]; ///< Reserved, must be zero.
    uint32_t partition;  ///< Flash partition to program and boot.
} __attribute__((packed));

struct vrtd_resp_cfgmem_program {
    uint8_t zero; ///< Placeholder; all data is carried via SCM_RIGHTS.
} __attribute__((packed));

enum vrtd_cfgmem_program_state {
    VRTD_CFGMEM_PROGRAM_STATE_QUEUED = 0,
    VRTD_CFGMEM_PROGRAM_STATE_RUNNING = 1,
    VRTD_CFGMEM_PROGRAM_STATE_DONE = 2,
    VRTD_CFGMEM_PROGRAM_STATE_FAILED = 3,
};

enum vrtd_cfgmem_program_phase {
    VRTD_CFGMEM_PROGRAM_PHASE_QUEUED = 0,
    VRTD_CFGMEM_PROGRAM_PHASE_OPENING_AMI = 1,
    VRTD_CFGMEM_PROGRAM_PHASE_DOWNLOADING_PDI = 2,
    VRTD_CFGMEM_PROGRAM_PHASE_SELECTING_PARTITION = 3,
    VRTD_CFGMEM_PROGRAM_PHASE_RESET_PREPARING = 4,
    VRTD_CFGMEM_PROGRAM_PHASE_REMOVING_PCIE = 5,
    VRTD_CFGMEM_PROGRAM_PHASE_TOGGLING_SBR = 6,
    VRTD_CFGMEM_PROGRAM_PHASE_RESCANNING_PCIE = 7,
    VRTD_CFGMEM_PROGRAM_PHASE_REDISCOVERING_DEVICE = 8,
    VRTD_CFGMEM_PROGRAM_PHASE_DONE = 9,
    VRTD_CFGMEM_PROGRAM_PHASE_FAILED = 10,
};

/**
 * @brief Progress snapshot for a cfgmem programming job.
 */
struct vrtd_cfgmem_program_status {
    uint64_t job_id;          ///< Job identifier returned by CFGMEM_PROGRAM_START.
    uint32_t state;           ///< One of enum vrtd_cfgmem_program_state.
    uint32_t phase;           ///< One of enum vrtd_cfgmem_program_phase.
    uint64_t bytes_written;   ///< PDI bytes written so far, if known.
    uint64_t bytes_total;     ///< Total PDI bytes to write, if known.
    uint64_t elapsed_msec;    ///< Milliseconds since job submission.
    uint16_t result;          ///< Final VRTD_RET_* when done/failed, otherwise VRTD_RET_OK.
} __attribute__((packed));

struct vrtd_req_cfgmem_program_start {
    uint32_t dev_number; ///< Device index (0-based).
    uint8_t boot_device; ///< AMI boot device selector (primary/secondary).
    uint8_t reserved[3]; ///< Reserved, must be zero.
    uint32_t partition;  ///< Flash partition to program and boot.
} __attribute__((packed));

struct vrtd_resp_cfgmem_program_start {
    uint64_t job_id; ///< Job identifier to use with CFGMEM_PROGRAM_STATUS.
} __attribute__((packed));

struct vrtd_req_cfgmem_program_status {
    uint64_t job_id; ///< Job identifier returned by CFGMEM_PROGRAM_START.
} __attribute__((packed));

struct vrtd_resp_cfgmem_program_status {
    struct vrtd_cfgmem_program_status status;
} __attribute__((packed));

enum vrtd_device_hotplug_op {
    VRTD_DEVICE_HOTPLUG_OP_RESCAN = 0,
    VRTD_DEVICE_HOTPLUG_OP_REMOVE = 1,
    VRTD_DEVICE_HOTPLUG_OP_TOGGLE_SBR = 2,
    VRTD_DEVICE_HOTPLUG_OP_HOTPLUG = 3,
    VRTD_DEVICE_HOTPLUG_OP_RESET_SEQUENCE = 4,
};

#define VRTD_DEVICE_HOTPLUG_FUNCTION_ALL UINT8_MAX

/**
 * @brief Request a PCIe hotplug operation for a device.
 *
 * RESCAN is device-independent; dev_number and function are ignored.
 * For RESET_SEQUENCE, shell_type selects the shell partition to boot and
 * function is ignored.
 *
 * For REMOVE and HOTPLUG, function selects the PCI physical function (0-7)
 * or VRTD_DEVICE_HOTPLUG_FUNCTION_ALL for all V80 PFs.  TOGGLE_SBR always
 * requires a single PCI physical function (0-7).
 */
struct vrtd_req_device_hotplug_op {
    uint32_t dev_number; ///< Device index (0-based).
    uint8_t op;          ///< One of vrtd_device_hotplug_op.
    uint8_t function;    ///< PCI function number (0-7), or FUNCTION_ALL where allowed.
    uint8_t shell_type;  ///< One of vrtd_shell_type for RESET_SEQUENCE.
} __attribute__((packed));

struct vrtd_resp_device_hotplug_op {
    uint8_t zero; ///< Placeholder to avoid empty-struct ABI issues.
} __attribute__((packed));

/**
 * @brief Set vrtd's in-memory shell state for a device.
 *
 * Requires the same hotplug permission as disruptive PCIe operations.  The
 * daemon accepts shell_type only while the current shell is UNKNOWN; jtag is a
 * set-only flag that is cleared by device rediscovery/reset.
 */
struct vrtd_req_set_shell_state {
    uint32_t dev_number; ///< Device index (0-based).
    uint8_t shell_type;  ///< One of vrtd_shell_type.
    uint8_t jtag;        ///< Non-zero to mark the device as JTAG-booted.
} __attribute__((packed));

struct vrtd_resp_set_shell_state {
    uint8_t zero; ///< Placeholder to avoid empty-struct ABI issues.
} __attribute__((packed));

enum vrtd_clock_region {
    VRTD_CLOCK_REGION_SERVICE = 0,
    VRTD_CLOCK_REGION_USER = 1,
};

enum vrtd_clock_op {
    VRTD_CLOCK_OP_GET = 0,
    VRTD_CLOCK_OP_SET = 1,
};

/**
 * @brief Request a clock operation (get/set) for a region.
 */
struct vrtd_req_clock_op {
    uint32_t dev_number; ///< Device index (0-based).
    uint32_t rate_hz;    ///< Desired rate for SET; ignored for GET.
    uint8_t op;         ///< One of vrtd_clock_op.
    uint8_t region;     ///< One of vrtd_clock_region.
} __attribute__((packed));

struct vrtd_resp_clock_op {
    uint32_t rate_hz; ///< Current/achieved rate for GET/SET.
} __attribute__((packed));

/**
 * @brief Maximum number of sensor entries that fit in a single response message.
 */
#define VRTD_SENSOR_MAX_ENTRIES \
    ((VRTD_MSG_MAX_SIZE - sizeof(struct vrtd_resp_header) - sizeof(uint32_t)) \
     / sizeof(struct vrtd_sensor_entry))

/**
 * @brief A single sensor reading.
 *
 * Each entry corresponds to one (sensor-name, sensor-type) pair.
 * For example, "vccint" may produce separate entries for temperature,
 * voltage, current, and power.
 */
struct vrtd_sensor_entry {
    char name[64];   ///< Sensor name (e.g., "vccint").
    uint8_t type;    ///< Sensor type bitmask (1=temp, 2=current, 4=voltage, 8=power).
    uint8_t status;  ///< Sensor status (0x01 = OK, see AMI sensor status codes).
    int8_t unit_mod; ///< Unit modifier exponent (e.g., -3 for milli-).
    uint8_t _pad;    ///< Reserved, must be zero.
    int32_t value;   ///< Sensor reading (apply 10^unit_mod to get base unit value).
} __attribute__((packed));

/**
 * @brief Request sensor information for a device.
 *
 * The daemon opens an AMI handle, discovers sensors, reads their values,
 * and returns them all in the response.
 */
struct vrtd_req_get_sensor_info {
    uint32_t dev_number; ///< Device index (0-based).
} __attribute__((packed));

/**
 * @brief Response to VRTD_REQ_GET_SENSOR_INFO.
 *
 * Contains a variable number of sensor entries.  The actual response size
 * is sizeof(num_sensors) + num_sensors * sizeof(struct vrtd_sensor_entry).
 */
struct vrtd_resp_get_sensor_info {
    uint32_t num_sensors; ///< Number of sensor entries following.
    struct vrtd_sensor_entry sensors[]; ///< Variable-length array of sensor entries.
} __attribute__((packed));

#ifdef __cplusplus
} // extern "C"
#endif

#endif // VRTD_WIRE_H
