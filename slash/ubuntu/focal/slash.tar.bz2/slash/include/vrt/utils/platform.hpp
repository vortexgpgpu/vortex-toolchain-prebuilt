/**
 * The MIT License (MIT)
 * Copyright (c) 2025-2026 Advanced Micro Devices, Inc. All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 * and associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/**
 * @file platform.hpp
 * @brief Platform enum for hardware, emulation, and simulation targets.
 */

#ifndef VRT_PLATFORM_HPP
#define VRT_PLATFORM_HPP

namespace vrt {
/**
 * @brief Enum for execution platforms.
 *
 * This enum represents the different execution platforms that can be used
 * for running applications and kernels.
 */
enum class Platform {
    HARDWARE,    ///< Hardware platform (actual FPGA device)
    EMULATION,   ///< Emulation platform (software emulation of hardware)
    SIMULATION,  ///< Simulation platform (software simulation)
    UNKNOWN      ///< Unknown or unspecified platform
};

/**
 * @brief Enum for hardware shell variants.
 */
enum class ShellType {
    SERVICE,  ///< Service shell (flash partition 0)
    COMPUTE,  ///< Compute shell (flash partition 1)
    UNKNOWN   ///< Unknown or unspecified shell
};

}  // namespace vrt

#endif  // VRT_PLATFORM_HPP