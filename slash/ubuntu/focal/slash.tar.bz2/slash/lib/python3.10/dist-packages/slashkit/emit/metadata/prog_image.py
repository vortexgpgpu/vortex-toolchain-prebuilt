# ##################################################################################################
#  The MIT License (MIT)
#  Copyright (c) 2025-2026 Advanced Micro Devices, Inc. All rights reserved.
#
#  Permission is hereby granted, free of charge, to any person obtaining a copy of this software
#  and associated documentation files (the "Software"), to deal in the Software without restriction,
#  including without limitation the rights to use, copy, modify, merge, publish, distribute,
#  sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
#  furnished to do so, subject to the following conditions:
#
#  The above copyright notice and this permission notice shall be included in all copies or
#  substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
# NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
# DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# ##################################################################################################
from __future__ import annotations

import logging
import tarfile
from pathlib import Path

from slashkit.core.command_config import LinkerConfiguration
from slashkit.emit.metadata.design_uuid import stamp_system_map_uuid
from slashkit.emit.metadata.timing_freq import apply_timing_frequency_cap

logger = logging.getLogger(__name__)


def build_vbin(config: LinkerConfiguration) -> Path:
    """! @brief Build a compressed .vbin tarball for a project.

    @param project_name Project name used to locate results and name the archive.
    @param results_dir Optional override of the project results directory.
    @return Path to the generated .vbin file.
    """
    images_dir = config.build_dir / "images"
    service_layer_pdi_path = (
        images_dir
        / f"top_i_service_layer_service_layer_{config.project_name}_inst_0_partial.pdi"
    )
    slash_pdi_path = (
        images_dir /
        f"top_i_slash_slash_{config.project_name}_inst_0_partial.pdi"
    )
    util_xml = config.build_dir / \
        f"report_utilization_{config.project_name}.xml"
    system_map = config.build_dir / "system_map.xml"

    files = [slash_pdi_path, util_xml, system_map]
    if config.networking_enabled:
        files.append(service_layer_pdi_path)

    for file in files:
        if not file.exists():
            raise FileNotFoundError(file)

    # Cap the recorded ClockFrequency to what routed WNS allows, measured
    # against the frequency the build was actually constrained at. VRT
    # programs the shell's clocking wizard from this value at device open,
    # so a design that misses timing runs at its achievable clock instead
    # of silently claiming the request.
    # Measure WNS against the period the design was actually constrained at,
    # which the RM build records. Falling back to the requested frequency is
    # only safe when the two agree; when a constraint fails to apply they do
    # not, and dividing WNS into the request reports a frequency far above
    # what the design closed at.
    base_freq_hz = config.user_clk_freq_hz
    period_file = config.build_dir / "user_clk_period_ns.txt"
    try:
        period_ns = float(period_file.read_text().strip())
        if period_ns > 0:
            actual_hz = int(1e9 / period_ns)
            if actual_hz != base_freq_hz:
                logger.warning(
                    "Design was timed at %d Hz but %d Hz was requested; "
                    "capping against the timed frequency.",
                    actual_hz, base_freq_hz,
                )
            base_freq_hz = actual_hz
    except (OSError, ValueError):
        logger.warning(
            "No recorded constraint period at %s; capping against the "
            "requested %d Hz.", period_file, base_freq_hz,
        )

    apply_timing_frequency_cap(
        project_name=config.project_name,
        system_map_path=system_map,
        base_freq_hz=base_freq_hz,
        hw_build_dir=config.build_dir,
    )

    # Give this vbin its identity. vrtd skips a design write when the board
    # already holds a design with the same UUID, so every archive written here
    # gets a new one, even when it is rebuilt from the same build directory.
    design_uuid = stamp_system_map_uuid(system_map)
    logger.info("Design UUID: %s", design_uuid)

    logger.info("Creating vbin archive: %s", config.out_path)

    with tarfile.open(config.out_path, "w:gz") as tf:
        for path in files:
            arcname = path.relative_to(config.build_dir)
            logger.info("Adding to vbin: %s", arcname)
            tf.add(path, arcname=str(arcname))

    logger.info("vbin archive complete: %s", config.out_path)
    return config.out_path
