#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "vrtd::libvrtd" for configuration "RelWithDebInfo"
set_property(TARGET vrtd::libvrtd APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(vrtd::libvrtd PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvrtd.so.1.0.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libvrtd.so.1"
  )

list(APPEND _cmake_import_check_targets vrtd::libvrtd )
list(APPEND _cmake_import_check_files_for_vrtd::libvrtd "${_IMPORT_PREFIX}/lib/libvrtd.so.1.0.0" )

# Import target "vrtd::libvrtdpp" for configuration "RelWithDebInfo"
set_property(TARGET vrtd::libvrtdpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(vrtd::libvrtdpp PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvrtdpp.so.1.0.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libvrtdpp.so.1"
  )

list(APPEND _cmake_import_check_targets vrtd::libvrtdpp )
list(APPEND _cmake_import_check_files_for_vrtd::libvrtdpp "${_IMPORT_PREFIX}/lib/libvrtdpp.so.1.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
