#define STA_VERSION "2.7.0"

#define STA_GIT_SHA1 "d5761004cd2cd2bcfa85d73327867966c279c83d"

#define ZLIB_FOUND

#define SSTA 0

#define TCL_READLINE 1
