// OpenSTA, Static Timing Analyzer
// Copyright (c) 2026, Parallax Software, Inc.
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
// 
// The origin of this software must not be misrepresented; you must not
// claim that you wrote the original software.
// 
// Altered source versions must be plainly marked as such, and must not be
// misrepresented as being the original software.
// 
// This notice may not be removed or altered from any source distribution.

#pragma once

#include <set>
#include <vector>

#include "LibertyClass.hh"
#include "NetworkClass.hh"
#include "SdcClass.hh"

namespace sta {

class TimingRole;
class DisabledCellPorts;
class DisabledInstancePorts;

using DisabledInstancePortsSeq = std::vector<DisabledInstancePorts*>;
using DisabledCellPortsSeq = std::vector<DisabledCellPorts*>;
using LibertyPortPairSeq = std::vector<LibertyPortPair>;
using TimingArcSetSet = std::set<TimingArcSet*, TimingArcSetLess>;

// Base class for disabled cell and instance ports.
class DisabledPorts
{
public:
  ~DisabledPorts();
  void setDisabledAll();
  void removeDisabledAll();
  void setDisabledFrom(LibertyPort *port);
  void removeDisabledFrom(LibertyPort *port);
  void setDisabledTo(LibertyPort *port);
  void removeDisabledTo(LibertyPort *port);
  void setDisabledFromTo(LibertyPort *from,
                         LibertyPort *to);
  void removeDisabledFromTo(LibertyPort *from,
                            LibertyPort *to);
  [[nodiscard]] bool isDisabled(LibertyPort *from,
                                 LibertyPort *to,
                                 const TimingRole *role);
  LibertyPortPairSet *fromTo() const { return from_to_; }
  LibertyPortSet *from() const { return from_; }
  LibertyPortSet *to() const { return to_; }
  [[nodiscard]] bool all() const { return all_; }

private:
  bool all_{false};
  LibertyPortSet *from_{nullptr};
  LibertyPortSet *to_{nullptr};
  LibertyPortPairSet *from_to_{nullptr};
};

// set_disable_timing cell [-from] [-to]
class DisabledCellPorts : public DisabledPorts
{
public:
  DisabledCellPorts(LibertyCell *cell);
  ~DisabledCellPorts();
  LibertyCell *cell() const { return cell_; }
  void setDisabled(TimingArcSet *arc_set);
  void removeDisabled(TimingArcSet *arc_set);
  [[nodiscard]] bool isDisabled(TimingArcSet *arc_set) const;
  TimingArcSetSet *timingArcSets() const { return arc_sets_; }

  using DisabledPorts::isDisabled;

private:
  LibertyCell *cell_;
  TimingArcSetSet *arc_sets_{nullptr};
};

// set_disable_timing instance [-from] [-to]
class DisabledInstancePorts : public DisabledPorts
{
public:
  DisabledInstancePorts(Instance *inst);
  Instance *instance() const { return inst_; }

private:
  Instance *inst_;
};

DisabledCellPortsSeq
sortByName(const DisabledCellPortsMap *cell_map);
DisabledInstancePortsSeq
sortByPathName(const DisabledInstancePortsMap *inst_map,
               const Network *network);
LibertyPortPairSeq
sortByName(const LibertyPortPairSet *set);

} // namespace sta
