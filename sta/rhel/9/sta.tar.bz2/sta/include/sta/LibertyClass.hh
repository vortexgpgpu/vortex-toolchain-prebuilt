// OpenSTA, Static Timing Analyzer
// Copyright (c) 2026, Parallax Software, Inc.
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
// 
// The origin of this software must not be misrepresented; you must not
// claim that you wrote the original software.
// 
// Altered source versions must be plainly marked as such, and must not be
// misrepresented as being the original software.
// 
// This notice may not be removed or altered from any source distribution.

#pragma once

#include <map>
#include <memory>
#include <set>
#include <vector>

namespace sta {

class Units;
class Unit;
class LibertyLibrary;
class LibertyCell;
class LibertyPort;
class Pvt;
class OperatingConditions;
class BusDcl;
class ModeDef;
class ModeValueDef;
class TableTemplate;
class Table;
class TableModel;
class TableAxis;
class GateTimingModel;
class CheckTimingModel;
class ScaleFactors;
class Wireload;
class WireloadSelection;
class TimingArcSet;
class TimingArc;
class TimingArcAttrs;
class InternalPower;
class LeakagePower;
class Sequential;
class FuncExpr;
class TimingModel;
class TimingRole;
class Transition;
class RiseFall;
class RiseFallBoth;
class ReceiverModel;
class Statetable;
class StatetableRow;

using LibertyLibrarySeq = std::vector<LibertyLibrary*>;
using LibertyCellSeq = std::vector<LibertyCell*>;
using SequentialSeq = std::vector<Sequential>;
using LibertyCellEquivMap = std::map<LibertyCell*, LibertyCellSeq*>;
using LibertyPortSeq = std::vector<LibertyPort*>;
using LibertyPortSet = std::set<LibertyPort*>;
using LibertyPortPair = std::pair<const LibertyPort*,const LibertyPort*>;
using LibertyCellSet = std::set<LibertyCell*>;
using TablePtr = std::shared_ptr<Table>;
using TimingArcAttrsPtr = std::shared_ptr<TimingArcAttrs>;
using TableAxisPtr = std::shared_ptr<TableAxis>;
using ReceiverModelPtr = std::shared_ptr<ReceiverModel>;
using StatetableRows = std::vector<StatetableRow>;

enum class ScaleFactorType : unsigned {
  pin_cap,
  wire_cap,
  wire_res,
  min_period,
  // Liberty attributes with rise/fall suffix.
  cell,
  hold,
  setup,
  recovery,
  removal,
  nochange,
  skew,
  leakage_power,
  internal_power,
  // Liberty attributes with rise/fall prefix.
  transition,
  // Liberty attributes with low/high suffix (indexed as rise/fall).
  min_pulse_width,
  unknown,
};
const int scale_factor_type_count = static_cast<int>(ScaleFactorType::unknown) + 1;
// Enough bits to hold a ScaleFactorType enum.
const int scale_factor_bits = 4;

enum class WireloadTree { worst_case, best_case, balanced, unknown };

enum class WireloadMode { top, enclosed, segmented, unknown };

enum class TimingSense {
  positive_unate,
  negative_unate,
  non_unate,
  none,
  unknown
};
const int timing_sense_count = static_cast<int>(TimingSense::unknown) + 1;
const int timing_sense_bit_count = 3;

enum class TableAxisVariable {
  total_output_net_capacitance,
  equal_or_opposite_output_net_capacitance,
  input_net_transition,
  input_transition_time,
  related_pin_transition,
  constrained_pin_transition,
  output_pin_transition,
  connect_delay,
  related_out_total_output_net_capacitance,
  time,
  iv_output_voltage,
  input_noise_width,
  input_noise_height,
  input_voltage,
  output_voltage,
  path_depth,
  path_distance,
  normalized_voltage,
  unknown
};

enum class PathType { clk, data, clk_and_data };
const int path_type_count = 2;

class LibertyPortLess
{
public:
  bool operator()(const LibertyPort *port1, const LibertyPort *port2) const;
};

class LibertyPortNameLess
{
public:
  bool operator()(const LibertyPort *port1, const LibertyPort *port2) const;
};

class LibertyPortPairLess
{
public:
  bool operator()(const LibertyPortPair &pair1,
                  const LibertyPortPair &pair2) const;
};

bool
timingArcSetLess(const TimingArcSet *set1,
                 const TimingArcSet *set2);

class TimingArcSetLess
{
public:
  bool
  operator()(const TimingArcSet *set1,
             const TimingArcSet *set2) const
  {
    return timingArcSetLess(set1, set2);
  }
};

} // namespace sta
