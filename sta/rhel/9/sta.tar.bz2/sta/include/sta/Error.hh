// OpenSTA, Static Timing Analyzer
// Copyright (c) 2026, Parallax Software, Inc.
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
// 
// The origin of this software must not be misrepresented; you must not
// claim that you wrote the original software.
// 
// Altered source versions must be plainly marked as such, and must not be
// misrepresented as being the original software.
// 
// This notice may not be removed or altered from any source distribution.

#pragma once

#include <exception>
#include <string>

#include "Report.hh"

namespace sta {

// Abstract base class for sta exceptions.
class Exception : public std::exception
{
public:
  const char *what() const noexcept override = 0;
};

class ExceptionMsg : public Exception
{
public:
  ExceptionMsg(const std::string &msg,
               bool suppressed);
  const char *what() const noexcept override;
  bool suppressed() const { return suppressed_; }

private:
  std::string msg_;
  bool suppressed_;
};

class ExceptionLine : public Exception
{
public:
  ExceptionLine(const std::string &filename,
                int line);

protected:
  std::string filename_;
  int line_;
};

// Failure opening filename for reading.
class FileNotReadable : public Exception
{
public:
  FileNotReadable(std::string_view filename);
  const char *what() const noexcept override;

protected:
  std::string msg_;
};

// Failure opening filename for writing.
class FileNotWritable : public Exception
{
public:
  FileNotWritable(std::string_view filename);
  const char *what() const noexcept override;

protected:
  std::string msg_;
};

// Report an error condition that should not be possible.
// The default handler prints msg to stderr and exits.
// The msg should NOT include a period or return.
// Only for use in those cases where a Report object is not available.
#define criticalError(id, msg) \
  Report::defaultReport()->fileCritical(id, __FILE__, __LINE__, msg)

} // namespace sta
