// OpenSTA, Static Timing Analyzer
// Copyright (c) 2026, Parallax Software, Inc.
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
// 
// The origin of this software must not be misrepresented; you must not
// claim that you wrote the original software.
// 
// Altered source versions must be plainly marked as such, and must not be
// misrepresented as being the original software.
// 
// This notice may not be removed or altered from any source distribution.

#pragma once

#include <string>

#include "SdcClass.hh"
#include "SdcCmdComment.hh"

namespace sta {

class ClockGroups : public SdcCmdComment
{
public:
  ClockGroups(std::string_view name,
              bool logically_exclusive,
              bool physically_exclusive,
              bool asynchronous,
              bool allow_paths,
              std::string_view comment);
  ~ClockGroups();
  void makeClockGroup(ClockSet *clks);
  const std::string &name() const { return name_; }
  ClockGroupSet *groups() { return &groups_; }
  bool logicallyExclusive() const { return logically_exclusive_; }
  bool physicallyExclusive() const { return physically_exclusive_; }
  bool asynchronous() const { return asynchronous_; }
  bool allowPaths() const { return allow_paths_; }
  void removeClock(Clock *clk);

private:
  std::string name_;
  bool logically_exclusive_;
  bool physically_exclusive_;
  bool asynchronous_;
  bool allow_paths_;
  ClockGroupSet groups_;
};

} // namespace sta
