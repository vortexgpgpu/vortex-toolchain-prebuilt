#pragma once

#define STA_VERSION "3.1.0"

#define STA_GIT_SHA1 "2f6ccdaeee33bca0073918bafe352000ce243f5a"

#define ZLIB_FOUND

#define HAVE_CXX_STD_FORMAT 0

#define TCL_READLINE 0
