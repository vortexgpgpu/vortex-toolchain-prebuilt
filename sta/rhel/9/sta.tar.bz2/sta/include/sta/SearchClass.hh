// OpenSTA, Static Timing Analyzer
// Copyright (c) 2026, Parallax Software, Inc.
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
// 
// The origin of this software must not be misrepresented; you must not
// claim that you wrote the original software.
// 
// Altered source versions must be plainly marked as such, and must not be
// misrepresented as being the original software.
// 
// This notice may not be removed or altered from any source distribution.

#pragma once

#include <functional>
#include <limits>
#include <map>
#include <vector>

#include "Delay.hh"
#include "GraphClass.hh"
#include "LibertyClass.hh"
#include "MinMaxValues.hh"
#include "NetworkClass.hh"
#include "RiseFallMinMaxDelay.hh"
#include "SdcClass.hh"
#include "VectorMap.hh"

namespace sta {

class Search;
class Scene;
class Path;
class PathEnd;
class PathGroup;
class Tag;
class TagIndexLess;
class TagMatchLess;
class TagLess;
class TagHash;
class TagEqual;
class TagGroup;
class TagGroupHash;
class TagGroupEqual;
class ClkInfo;
class ClkInfoHash;
class ClkInfoEqual;
class VertexPathIterator;
class MinPulseWidthCheck;
class MinPeriodCheck;
class MaxSkewCheck;
class SearchPred;
class BfsFwdIterator;
class ClkDelays;

// Tag compare using tag matching (tagMatch) critera.
class TagMatchLess
{
public:
  TagMatchLess(bool match_crpr_clk_pin,
               const StaState *sta);
  bool operator()(const Tag *tag1,
                  const Tag *tag2) const;

protected:
  bool match_crpr_clk_pin_;
  const StaState *sta_;
};

class TagMatchHash
{
public:
  TagMatchHash(bool match_crpr_clk_pin,
               const StaState *sta);
  size_t operator()(const Tag *tag) const;

protected:
  bool match_crpr_clk_pin_;
  const StaState *sta_;
};

class TagMatchEqual
{
public:
  TagMatchEqual(bool match_crpr_clk_pin,
                const StaState *sta);
  bool operator()(const Tag *tag1, 
                  const Tag *tag2) const;

protected:
  bool match_crpr_clk_pin_;
  const StaState *sta_;
};

using PathAPIndex = int;
using TagIndex = uint32_t;
using TagSeq = std::vector<Tag*>;
using PathEndSeq = std::vector<PathEnd*>;
using ArrivalSeq = std::vector<Arrival>;
using VertexPathCountMap = std::map<Vertex*, size_t>;
using PathIndexMap = VectorMap<Tag*, size_t, TagMatchLess>;
using SlackSeq = std::vector<Slack>;
using Crpr = Delay;
using PathSeq = std::vector<Path*>;
using ConstPathSeq = std::vector<const Path*>;
// Path::slack/arrival/required function.
using PathDelayFunc = std::function<Delay (const Path *path)>;
using DelaysWrtClks = std::map<const ClockEdge*, RiseFallMinMaxDelay>;

enum class ReportPathFormat { full,
                              full_clock,
                              full_clock_expanded,
                              shorter,
                              endpoint,
                              summary,
                              slack_only,
                              json
};

static const TagIndex tag_index_bit_count = 28;
static const TagIndex tag_index_max = (1 << tag_index_bit_count) - 1;
static const TagIndex tag_index_null = tag_index_max;
static const int path_ap_index_bit_count = 8;
// One path analysis point per scene min/max.
static const int scene_count_max = (1 << path_ap_index_bit_count) / 2;

} // namespace sta
