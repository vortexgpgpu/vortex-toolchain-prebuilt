// OpenSTA, Static Timing Analyzer
// Copyright (c) 2026, Parallax Software, Inc.
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
// 
// The origin of this software must not be misrepresented; you must not
// claim that you wrote the original software.
// 
// Altered source versions must be plainly marked as such, and must not be
// misrepresented as being the original software.
// 
// This notice may not be removed or altered from any source distribution.

#pragma once

#include <limits>
#include <set>
#include <vector>

#include "Delay.hh"
#include "MinMax.hh"
#include "ObjectId.hh"
#include "Transition.hh"

namespace sta {

// Class declarations for pointer references.
class Graph;
class Vertex;
class Edge;
class VertexIterator;
class VertexInEdgeIterator;
class VertexOutEdgeIterator;

class VertexIdLess
{
public:
  VertexIdLess() = delete;
  VertexIdLess(Graph *&graph);
  bool operator()(const Vertex *vertex1,
                  const Vertex *vertex2) const;

private:
  Graph *&graph_;
};

using VertexId = ObjectId;
using EdgeId = ObjectId;
using VertexSeq = std::vector<Vertex*>;
using VertexSet = std::set<Vertex*, VertexIdLess>;
using EdgeSeq = std::vector<Edge*>;
using EdgeSet = std::set<Edge*>;
using Level = int;
using DcalcAPIndex = int;
using TagGroupIndex = int;
using SlewSeq = std::vector<Slew>;
using VertexFn = std::function<void(Vertex*)>;
using EdgeFn = std::function<void(Edge *, Vertex*)>;

static constexpr int level_max = std::numeric_limits<Level>::max();

// 16,777,215 tags
static constexpr int tag_group_index_bits = 24;
static constexpr TagGroupIndex tag_group_index_max = (1<<tag_group_index_bits)-1;
static constexpr int slew_annotated_bits = MinMax::index_count * RiseFall::index_count;

// Bit shifts used to mark vertices in a Bfs queue.
enum class BfsIndex { dcalc, arrival, required, other, bits };

} // namespace sta
