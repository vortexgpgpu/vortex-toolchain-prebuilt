// OpenSTA, Static Timing Analyzer
// Copyright (c) 2026, Parallax Software, Inc.
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
// 
// The origin of this software must not be misrepresented; you must not
// claim that you wrote the original software.
// 
// Altered source versions must be plainly marked as such, and must not be
// misrepresented as being the original software.
// 
// This notice may not be removed or altered from any source distribution.

#pragma once

#include <map>

#include "LibertyClass.hh"
#include "StaState.hh"

struct DdNode;
struct DdManager;

namespace sta {

using BddPortVarMap = std::map<const LibertyPort*, DdNode*, LibertyPortLess>;
using BddVarIdxPortMap = std::map<unsigned, const LibertyPort*>;

class Bdd : public StaState
{
public:
  Bdd(const StaState *sta);
  ~Bdd() override;
  DdNode *funcBdd(const FuncExpr *expr);
  DdNode *findNode(const LibertyPort *port);
  const LibertyPort *nodePort(DdNode *node);
  DdNode *ensureNode(const LibertyPort *port);
  const LibertyPort *varIndexPort(int var_index);
  BddPortVarMap &portVarMap() { return bdd_port_var_map_; }

  void clearVarMap();
  DdManager *cuddMgr() const { return cudd_mgr_; }

private:
  DdManager *cudd_mgr_;
  BddPortVarMap bdd_port_var_map_;
  BddVarIdxPortMap bdd_var_idx_port_map_;
};

} // namespace sta
