#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hip::CHIP" for configuration "Release"
set_property(TARGET hip::CHIP APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hip::CHIP PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libCHIP.so"
  IMPORTED_SONAME_RELEASE "libCHIP.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS hip::CHIP )
list(APPEND _IMPORT_CHECK_FILES_FOR_hip::CHIP "${_IMPORT_PREFIX}/lib/libCHIP.so" )

# Import target "hip::ocml_host_math_funcs" for configuration "Release"
set_property(TARGET hip::ocml_host_math_funcs APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hip::ocml_host_math_funcs PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libocml_host_math_funcs.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS hip::ocml_host_math_funcs )
list(APPEND _IMPORT_CHECK_FILES_FOR_hip::ocml_host_math_funcs "${_IMPORT_PREFIX}/lib/libocml_host_math_funcs.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
