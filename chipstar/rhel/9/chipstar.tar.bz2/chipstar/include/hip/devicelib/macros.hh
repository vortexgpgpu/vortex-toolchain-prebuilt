/*
 * Copyright (c) 2021-22 chipStar developers
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */


#ifndef HIP_INCLUDE_DEVICELIB_MACROS_H
#define HIP_INCLUDE_DEVICELIB_MACROS_H

// Device-compatible type definitions
#ifndef HIP_UINT_DEFINED
#define HIP_UINT_DEFINED
typedef unsigned int uint;
#endif

#ifndef HIP_ULONG_DEFINED
#define HIP_ULONG_DEFINED
typedef unsigned long ulong;
#endif

#ifndef __HIP_DEVICE_COMPILE__
#include <stddef.h>
#else
#ifndef HIP_SIZE_T_DEFINED
#define HIP_SIZE_T_DEFINED
// Phase 3 of chipstar_opencl_32bit proposal: size_t must follow the
// device's pointer width. On spirv64 this is unsigned long; on spirv32
// it is unsigned int. Use the compiler's built-in __SIZE_TYPE__ so the
// device-side size_t matches the target triple.
typedef __SIZE_TYPE__ size_t;
#endif
#endif

#if defined(__HIP_DEVICE_COMPILE__) && !defined(__HIP__)
#ifndef HIP_CLOCK_T_DEFINED
#define HIP_CLOCK_T_DEFINED
typedef long clock_t;
#endif
#endif

#define NOOPT __attribute__((optnone))

#if defined(__HIP_DEVICE_COMPILE__)
// #include <algorithm>
// #include <limits>
#define __DEVICE__ __device__
#define EXPORT static inline __device__
#define OVLD __attribute__((overloadable)) __device__
#define NON_OVLD __device__
#define GEN_NAME(N) __chip_##N
#define GEN_NAME2(N, S) __chip_##N##_##S
#else
#define __DEVICE__ extern __device__
#define EXPORT extern __device__
#define NON_OVLD
#define OVLD
#define GEN_NAME(N) N
#define GEN_NAME2(N, S) N
#endif // __HIP_DEVICE_COMPILE__

#ifndef INT_MAX
#define INT_MAX 2147483647
#endif

typedef _Float16 api_half;
typedef _Float16 api_half2 __attribute__((ext_vector_type(2)));

#endif // include guard
