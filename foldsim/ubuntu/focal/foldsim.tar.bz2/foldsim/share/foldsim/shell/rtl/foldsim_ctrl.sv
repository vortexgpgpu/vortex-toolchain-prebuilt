// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "foldsim_regs.vh"

// The host's view of a foldsim simulator: an AXI4-Lite register block, and the
// endpoint that drives the target's control inputs from it.
//
// The target runs free: the endpoint gives it a token every cycle. The host
// queues commands -- a DCR write or read, a start, a reset -- and each is
// applied to the target for one cycle (a reset for its count of cycles), in
// order, from the cycle after the queue reaches it. The memory endpoint gets
// the target's reset for each target cycle too, and resets its side of the
// target's memory port with it (foldsim_mem). A DCR read's response is
// kept for the host; `busy` covers everything queued or in flight, so a host
// that sees the target idle has every effect of what it asked for.
//
// See foldsim_regs.vh for the register map.
module foldsim_ctrl #(
    parameter DCR_ADDR_W   = 12,
    parameter DCR_DATA_W   = 32,
    parameter QUEUE        = 16,
    parameter RESET_CYCLES = 64,
    parameter NUM_CLASSES  = 1,
    // The memory endpoints, one per memory port of the target.
    parameter MEM_PORTS    = 1,
    // MEM_CAPS: what the memory endpoints' bank models were built with.
    parameter MEM_CAPS     = 32'd0,
    // The simulator takes idle slots (foldsim --bubbles): FOLDSIM_REG_BUBBLE
    // holds a rate, else it stays 0.
    parameter BUBBLES      = 0,
    // The device memory the simulator's virtual memories need (0: none).
    parameter [63:0] VMEM_BYTES = 64'd0,
    // The virtual memories' controllers with telemetry counters (foldsim_vmem
    // `tel`): FOLDSIM_REG_VMEM_TEL_SEL picks one, FOLDSIM_REG_VMEM_TEL reads
    // its counters (0: none, both read zero).
    parameter VMEM_TEL_N   = 0
) (
    input  wire                  clk,
    input  wire                  reset,

    input  wire                  s_awvalid,
    output wire                  s_awready,
    // Registers are words: an address's byte bits are not decoded.
    /* verilator lint_off UNUSEDSIGNAL */
    input  wire [11:0]           s_awaddr,
    /* verilator lint_on UNUSEDSIGNAL */
    input  wire                  s_wvalid,
    output wire                  s_wready,
    input  wire [31:0]           s_wdata,
    output reg                   s_bvalid,
    input  wire                  s_bready,
    input  wire                  s_arvalid,
    output wire                  s_arready,
    input  wire [11:0]           s_araddr,
    output reg                   s_rvalid,
    input  wire                  s_rready,
    output reg  [31:0]           s_rdata,

    // The memory endpoints' settings and state: where the target's memory
    // is, and the bank model's settings and counters (foldsim_mem_bank).
    output reg  [63:0]           mem_base,
    output reg  [31:0]           mem_clock,
    output reg  [15:0]           mem_latency,
    output reg  [31:0]           mem_queue,
    output reg  [12:0]           mem_geom,
    output reg  [15:0]           mem_wmark,
    output wire [18*12-1:0]      mem_timing,
    // Refresh: [0] on, [1] all banks; its interval and busy time (clocks).
    output wire [1:0]            mem_refresh,
    output reg  [15:0]           mem_refi,
    output reg  [15:0]           mem_rfc,
    output reg  [7:0]            bubble,
    // Where the virtual memories are, whether the simulator may use them, and
    // whether every row of theirs not written since the reset is zero. A
    // cycle's pulse when the region moves (VMEM_BASE_LO); their controllers
    // are still at it (STATUS bit 4).
    output wire [63:0]           vmem_base,
    output wire                  vmem_on,
    output wire                  vmem_zero,
    output wire                  vmem_move,
    input  wire                  vmem_moving,
    // The controller whose telemetry counters vmem_tel holds (a few cycles
    // after vmem_tel_sel changes: the kernel registers its selection).
    output wire [15:0]           vmem_tel_sel,
    input  wire [7*48-1:0]       vmem_tel,
    // Per memory port, its counters.
    input  wire [MEM_PORTS*8*64-1:0] mem_stats,
    // (A port past the 24th has no window for it.)
    /* verilator lint_off UNUSEDSIGNAL */
    input  wire [MEM_PORTS*8*32-1:0] mem_axi,
    /* verilator lint_on UNUSEDSIGNAL */
    // Each port's stall-reason word (foldsim_mem dbg).
    input  wire [MEM_PORTS*32-1:0]   mem_dbg,
    input  wire                  mem_idle,
    input  wire                  mem_error,
    input  wire                  mem_stall,
    // Which classes of the simulator's models finish a thread this cycle.
    input  wire [NUM_CLASSES-1:0] profile_finish,
    // The target's reset, a token per target cycle for each memory endpoint.
    output wire [MEM_PORTS-1:0]  mem_reset_valid,     input wire [MEM_PORTS-1:0] mem_reset_ready,
    output wire [MEM_PORTS-1:0]  mem_reset_bits,

    // Target inputs, as channels of the simulator: the endpoint's outputs.
    output wire                  reset_valid,         input wire reset_ready,         output wire                  reset_bits,
    output wire                  dcr_req_valid_valid, input wire dcr_req_valid_ready, output wire                  dcr_req_valid_bits,
    output wire                  dcr_req_rw_valid,    input wire dcr_req_rw_ready,    output wire                  dcr_req_rw_bits,
    output wire                  dcr_req_addr_valid,  input wire dcr_req_addr_ready,  output wire [DCR_ADDR_W-1:0] dcr_req_addr_bits,
    output wire                  dcr_req_data_valid,  input wire dcr_req_data_ready,  output wire [DCR_DATA_W-1:0] dcr_req_data_bits,
    output wire                  start_valid,         input wire start_ready,         output wire                  start_bits,

    // Target outputs: the endpoint's inputs.
    input  wire                  dcr_rsp_valid_valid, output wire dcr_rsp_valid_ready, input wire                  dcr_rsp_valid_bits,
    input  wire                  dcr_rsp_data_valid,  output wire dcr_rsp_data_ready,  input wire [DCR_DATA_W-1:0] dcr_rsp_data_bits,
    input  wire                  busy_valid,          output wire busy_ready,          input wire                  busy_bits
);
    if (NUM_CLASSES > 96 || MEM_PORTS > 32) begin : g_map
        $error("foldsim_ctrl: the register map holds up to 96 classes and 32 memory ports");
    end

    localparam QW = $clog2(QUEUE);
    localparam QC = $clog2(QUEUE + 1);

    // ---- Commands ----
    reg [2:0]            q_op   [QUEUE];
    reg [DCR_ADDR_W-1:0] q_addr [QUEUE];
    reg [DCR_DATA_W-1:0] q_data [QUEUE];
    reg [QW-1:0]         q_head, q_tail;
    reg [QC-1:0]         q_count;
    reg [DCR_ADDR_W-1:0] cmd_addr;
    reg [DCR_DATA_W-1:0] cmd_data;
    // The command applied this target cycle, taken from the queue when the
    // previous cycle finished: the target's control tokens are functions of it
    // alone, so they do not change between the target taking one and the
    // endpoint finishing the cycle.
    reg [2:0]            cur_op;
    reg [DCR_ADDR_W-1:0] cur_addr;
    reg [DCR_DATA_W-1:0] cur_data;

    reg                  run;
    reg [31:0]           reset_count;
    reg                  start_pending;
    reg [15:0]           start_wait;
    reg                  target_busy;
    reg                  rsp_valid;
    reg [DCR_DATA_W-1:0] rsp_data;
    reg [63:0]           target_cycles, host_cycles, mem_stalls;
    reg [47:0]           finishes [NUM_CLASSES];
    reg [1:0]            mem_refresh_r;
    reg [11:0]           mem_t [18];

    // The refresh in effect from a reset on: the memory endpoint takes it at
    // the end of every reset cycle, so a reset command's own cycle has it
    // already.
    assign mem_refresh = (cur_op == `FOLDSIM_CMD_RESET) ? cur_addr[1:0] : mem_refresh_r;
    for (genvar i = 0; i < 18; ++i) begin : g_mem_t
        assign mem_timing[i*12 +: 12] = mem_t[i];
    end
    // The default machine's DRAM (HBM2 at 800 MT/s behind a 400 MHz core),
    // until the runtime sets its own: tBL, tCCD_S, tCCD_L, tCL, tCWL,
    // tRCD_RD, tRCD_WR, tRP, tRAS, tRC, tRTP, tWR, tRRD_S, tRRD_L, tFAW,
    // tWTR_S, tWTR_L, read-to-write extra.
    localparam [18*12-1:0] MEM_T_RESET = {12'd2, 12'd2, 12'd2, 12'd6, 12'd2, 12'd2, 12'd5, 12'd2,
                                          12'd19, 12'd14, 12'd6, 12'd6, 12'd6, 12'd1, 12'd6, 12'd4,
                                          12'd2, 12'd2};

    wire       q_empty = (q_count == 0);

    // ---- The target's control inputs this cycle ----
    wire in_reset  = (reset_count != 0) | (cur_op == `FOLDSIM_CMD_RESET);
    wire dcr_valid = ~in_reset & ((cur_op == `FOLDSIM_CMD_DCR_WRITE) | (cur_op == `FOLDSIM_CMD_DCR_READ));
    wire dcr_rw    = (cur_op == `FOLDSIM_CMD_DCR_WRITE);
    wire do_start  = ~in_reset & (cur_op == `FOLDSIM_CMD_START);
    // Reset cycles left after this one; a reset command lasts its count of
    // cycles, at least one.
    wire [31:0] reset_next = (reset_count != 0) ? reset_count - 32'd1
                           : ((cur_op == `FOLDSIM_CMD_RESET) && (cur_data > 1)) ? 32'(cur_data) - 32'd1
                           : 32'd0;

    wire finish;
    wire finish_in;
    wire [6+MEM_PORTS-1:0] done;
    wire [2:0] have;
    foldsim_token_out #(1) o_reset   (clk, reset, reset_valid,         reset_ready,         run, finish, done[0]);
    foldsim_token_out #(1) o_dvalid  (clk, reset, dcr_req_valid_valid, dcr_req_valid_ready, run, finish, done[1]);
    foldsim_token_out #(1) o_drw     (clk, reset, dcr_req_rw_valid,    dcr_req_rw_ready,    run, finish, done[2]);
    foldsim_token_out #(1) o_daddr   (clk, reset, dcr_req_addr_valid,  dcr_req_addr_ready,  run, finish, done[3]);
    foldsim_token_out #(1) o_ddata   (clk, reset, dcr_req_data_valid,  dcr_req_data_ready,  run, finish, done[4]);
    foldsim_token_out #(1) o_start   (clk, reset, start_valid,         start_ready,         run, finish, done[5]);
    for (genvar p = 0; p < MEM_PORTS; ++p) begin : g_mreset
        foldsim_token_out #(1) o_mreset (clk, reset, mem_reset_valid[p], mem_reset_ready[p], run, finish, done[6+p]);
        assign mem_reset_bits[p] = in_reset;
    end
    assign reset_bits         = in_reset;
    assign dcr_req_valid_bits = dcr_valid;
    assign dcr_req_rw_bits    = dcr_rw;
    assign dcr_req_addr_bits  = cur_addr;
    assign dcr_req_data_bits  = cur_data;
    assign start_bits         = do_start;

    wire                  rsp_v, busy;
    wire [DCR_DATA_W-1:0] rsp_d;
    foldsim_token_in #(1, 1)          t_rspv (clk, reset, dcr_rsp_valid_valid, dcr_rsp_valid_ready, dcr_rsp_valid_bits, finish_in, have[0], rsp_v);
    foldsim_token_in #(DCR_DATA_W, 1) t_rspd (clk, reset, dcr_rsp_data_valid,  dcr_rsp_data_ready,  dcr_rsp_data_bits,  finish_in, have[1], rsp_d);
    foldsim_token_in #(1, 1)          t_busy (clk, reset, busy_valid,          busy_ready,          busy_bits,          finish_in, have[2], busy);

    // Staged token ends: the cycle finishes from the endpoint's registers, a
    // host cycle after its last token. The target's control tokens depend on
    // none of its outputs, so the cycle finishes on its own tokens alone; its
    // outputs (a DCR response, busy) are taken as they come, in cycle order,
    // and only tell the host.
    assign finish = run & (&done);
    assign finish_in = &have;

    // ---- The host's registers ----
    reg       aw_got, w_got, ar_got;
    // A read takes two host cycles: each window's word is registered, then
    // the address's window chooses among them.
    reg        rd_sel, r_in_tim, r_in_stat, r_in_fin, r_in_vm, r_in_tel;
    reg [31:0] r_tel;
    // The selected controller's counter of the address being read, 48 bits.
    wire [2:0]      tel_idx = 3'((ar_addr - `FOLDSIM_REG_VMEM_TEL) >> 3);
    wire [8*48-1:0] tel_pad = {48'd0, vmem_tel};
    wire [47:0]     tel_cnt = tel_pad[48 * tel_idx +: 48];
    reg [31:0] r_base, r_tim, r_stat, r_fin, r_vm;
    reg [11:2] aw_addr;
    reg [11:0] ar_addr;
    // Offsets into the counter and finish windows of the address being read.
    wire [11:0] stat_off = ar_addr - `FOLDSIM_REG_MEM_STATS;
    // The memory ports' telemetry windows, FOLDSIM_REG_MEM_AXI (0x480 + 0x20 per port, 24 ports at most) and
    // FOLDSIM_REG_MEM_DBG (0x780 + 4 per port, 32 at most), are read as the read is taken: words of the 0x400 block
    // by address bits, so the read data's selection has one stage for both and no address arithmetic.
    localparam AP = (MEM_PORTS < 24) ? MEM_PORTS : 24, DP = (MEM_PORTS < 32) ? MEM_PORTS : 32;
    wire [31:0] win_word [256];
    for (genvar i = 0; i < 256; ++i) begin : g_win
        if (i >= 32 && i < 32 + 8 * AP) begin : g_axi
            assign win_word[i] = mem_axi[(i - 32) * 32 +: 32];
        end else if (i >= 224 && i < 224 + DP) begin : g_dbg
            assign win_word[i] = mem_dbg[(i - 224) * 32 +: 32];
        end else begin : g_none
            assign win_word[i] = 32'd0;
        end
    end
    wire [7:0]  win_idx = s_araddr[9:2];
    wire        win_in  = (s_araddr[11:10] == 2'b01)
                        && (((win_idx >= 8'd32) && (32'(win_idx) < 32 + 8 * AP))
                         || ((win_idx >= 8'd224) && (32'(win_idx) < 224 + DP)));
    reg         win_hit;
    reg  [31:0] win_rdata;
    localparam CW = (NUM_CLASSES > 1) ? $clog2(NUM_CLASSES) : 1;
    wire [CW-1:0] fin_idx = CW'((ar_addr - `FOLDSIM_REG_FINISH_BASE) >> 3);
    reg [31:0] w_data;
    assign s_awready = ~aw_got;
    assign s_wready  = ~w_got;
    assign s_arready = ~ar_got & ~rd_sel & ~s_rvalid;

    wire wr      = aw_got & w_got & ~s_bvalid;
    // A virtual memories' move is under way (STATUS bit 4).
    wire vmem_busy;
    wire [11:0] wa = {aw_addr, 2'b00};
    wire push    = wr & (wa == `FOLDSIM_REG_CMD) & (q_count != QC'(QUEUE));
    // reset_next == 0 without its subtractions: a count runs out at 1, and a
    // reset command's count is only taken above 1.
    wire reset_last = (reset_count != 0) ? (reset_count == 32'd1)
                    : ~((cur_op == `FOLDSIM_CMD_RESET) && (cur_data > 1));
    wire pop     = finish & ~q_empty & reset_last;

    wire status_busy = ~q_empty | (cur_op != `FOLDSIM_CMD_NONE) | start_pending | target_busy
                     | ~mem_idle | (reset_count != 0);

    always @(posedge clk) begin
        if (reset) begin
            q_head            <= 0;
            q_tail            <= 0;
            q_count           <= 0;
            run               <= 1'b1;
            reset_count       <= RESET_CYCLES;
            cur_op            <= `FOLDSIM_CMD_NONE;
            start_pending     <= 1'b0;
            target_busy       <= 1'b0;
            rsp_valid         <= 1'b0;
            target_cycles     <= 0;
            host_cycles       <= 0;
            mem_stalls        <= 0;
            for (integer c = 0; c < NUM_CLASSES; ++c)
                finishes[c] <= 0;
            mem_base          <= 64'h40_0000_0000;
            bubble            <= 8'd0;
            mem_refresh_r     <= 2'd0;
            mem_refi          <= 16'd0;
            mem_rfc           <= 16'd0;
            mem_clock         <= {16'd400, 16'd800};
            mem_latency       <= 16'd0;
            mem_queue         <= {8'd32, 8'd32, 16'd0};
            mem_geom          <= {1'b1, 2'd2, 4'd5, 2'd2, 2'd2, 2'd1};
            mem_wmark         <= {8'd7, 8'd26};
            for (integer i = 0; i < 18; ++i)
                mem_t[i] <= MEM_T_RESET[i*12 +: 12];
            aw_got            <= 1'b0;
            w_got             <= 1'b0;
            ar_got            <= 1'b0;
            rd_sel            <= 1'b0;
            s_bvalid          <= 1'b0;
            s_rvalid          <= 1'b0;
        end else begin
            host_cycles <= host_cycles + 64'd1;
            if (mem_stall)
                mem_stalls <= mem_stalls + 64'd1;
            for (integer c = 0; c < NUM_CLASSES; ++c)
                if (profile_finish[c])
                    finishes[c] <= finishes[c] + 48'd1;

            // One target cycle of the endpoint.
            if (finish) begin
                target_cycles <= target_cycles + 64'd1;
                reset_count   <= reset_next;
                cur_op        <= pop ? q_op[q_head] : `FOLDSIM_CMD_NONE;
                cur_addr      <= q_addr[q_head];
                cur_data      <= q_data[q_head];
                // A reset command's address chooses the refresh the target
                // has from the reset on.
                if (cur_op == `FOLDSIM_CMD_RESET)
                    mem_refresh_r <= cur_addr[1:0];
            end
            // The target's outputs of a cycle.
            if (finish_in) begin
                if (rsp_v) begin
                    rsp_valid <= 1'b1;
                    rsp_data  <= rsp_d;
                end
                target_busy <= busy;
            end
            // A start counts as busy until the target says it is, or plainly
            // never will.
            if (finish & do_start) begin
                start_pending <= 1'b1;
                start_wait    <= 16'hffff;
            end else if (finish_in & start_pending) begin
                if (busy || start_wait == 0)
                    start_pending <= 1'b0;
                start_wait <= start_wait - 16'd1;
            end
            if (pop)
                q_head <= q_head + 1'b1;
            if (push) begin
                q_op[q_tail]   <= w_data[2:0];
                q_addr[q_tail] <= cmd_addr;
                q_data[q_tail] <= cmd_data;
                q_tail         <= q_tail + 1'b1;
                // A read's response is the next one.
                if (w_data[2:0] == `FOLDSIM_CMD_DCR_READ)
                    rsp_valid <= 1'b0;
            end
            q_count <= q_count + QC'(push) - QC'(pop);

            // AXI4-Lite: a write once both its address and data are in.
            if (s_awvalid & s_awready) begin
                aw_got  <= 1'b1;
                aw_addr <= s_awaddr[11:2];
            end
            if (s_wvalid & s_wready) begin
                w_got  <= 1'b1;
                w_data <= s_wdata;
            end
            if (wr) begin
                aw_got   <= 1'b0;
                w_got    <= 1'b0;
                s_bvalid <= 1'b1;
                case (wa)
                `FOLDSIM_REG_CTRL:        run <= w_data[0];
                `FOLDSIM_REG_CMD_ADDR:    cmd_addr <= DCR_ADDR_W'(w_data);
                `FOLDSIM_REG_CMD_DATA:    cmd_data <= DCR_DATA_W'(w_data);
                `FOLDSIM_REG_MEM_BASE_LO: mem_base[31:0] <= w_data;
                `FOLDSIM_REG_MEM_BASE_HI: mem_base[63:32] <= w_data;
                `FOLDSIM_REG_BUBBLE:      if (BUBBLES != 0) bubble <= w_data[7:0];
                `FOLDSIM_REG_MEM_CLOCK:   mem_clock <= w_data;
                `FOLDSIM_REG_MEM_LATENCY: mem_latency <= w_data[15:0];
                `FOLDSIM_REG_MEM_QUEUE:   mem_queue <= w_data;
                `FOLDSIM_REG_MEM_GEOM:    mem_geom <= w_data[12:0];
                `FOLDSIM_REG_MEM_WMARK:   mem_wmark <= w_data[15:0];
                `FOLDSIM_REG_MEM_REFI:    mem_refi <= w_data[15:0];
                `FOLDSIM_REG_MEM_RFC:     mem_rfc <= w_data[15:0];
                default:;
                endcase
                if (wa >= `FOLDSIM_REG_MEM_TIMING && wa < `FOLDSIM_REG_MEM_TIMING + 12'(4 * 18))
                    mem_t[5'((wa - `FOLDSIM_REG_MEM_TIMING) >> 2)] <= w_data[11:0];
            end
            if (s_bvalid & s_bready)
                s_bvalid <= 1'b0;

            if (s_arvalid & s_arready) begin
                ar_got  <= 1'b1;
                ar_addr <= s_araddr;
                win_hit   <= win_in;
                win_rdata <= win_word[win_idx];
            end
            if (ar_got) begin
                ar_got   <= 1'b0;
                rd_sel   <= 1'b1;
                case ({ar_addr[11:2], 2'b00})
                `FOLDSIM_REG_ID:          r_base <= `FOLDSIM_ID;
                `FOLDSIM_REG_VERSION:     r_base <= `FOLDSIM_VERSION;
                `FOLDSIM_REG_CTRL:        r_base <= {31'b0, run};
                `FOLDSIM_REG_STATUS:      r_base <= {27'b0, vmem_busy, mem_error, rsp_valid,
                                                     (q_count == QC'(QUEUE)), status_busy};
                `FOLDSIM_REG_CMD_ADDR:    r_base <= 32'(cmd_addr);
                `FOLDSIM_REG_CMD_DATA:    r_base <= 32'(cmd_data);
                `FOLDSIM_REG_DCR_RSP:     r_base <= 32'(rsp_data);
                `FOLDSIM_REG_TCYCLES_LO:  r_base <= target_cycles[31:0];
                `FOLDSIM_REG_TCYCLES_HI:  r_base <= target_cycles[63:32];
                `FOLDSIM_REG_HCYCLES_LO:  r_base <= host_cycles[31:0];
                `FOLDSIM_REG_HCYCLES_HI:  r_base <= host_cycles[63:32];
                `FOLDSIM_REG_MEM_BASE_LO: r_base <= mem_base[31:0];
                `FOLDSIM_REG_MEM_BASE_HI: r_base <= mem_base[63:32];
                `FOLDSIM_REG_BUBBLE:      r_base <= 32'(bubble);
                `FOLDSIM_REG_MSTALL_LO:   r_base <= mem_stalls[31:0];
                `FOLDSIM_REG_MSTALL_HI:   r_base <= mem_stalls[63:32];
                `FOLDSIM_REG_NUM_CLASSES: r_base <= 32'(NUM_CLASSES);
                `FOLDSIM_REG_VMEM_TEL_SEL: r_base <= (VMEM_TEL_N != 0) ? {8'd48, 8'd7, 16'(VMEM_TEL_N)} : 32'd0;
                `FOLDSIM_REG_MEM_REFRESH: r_base <= 32'(mem_refresh_r);
                `FOLDSIM_REG_MEM_CAPS:    r_base <= MEM_CAPS;
                `FOLDSIM_REG_MEM_CLOCK:   r_base <= mem_clock;
                `FOLDSIM_REG_MEM_LATENCY: r_base <= 32'(mem_latency);
                `FOLDSIM_REG_MEM_QUEUE:   r_base <= mem_queue;
                `FOLDSIM_REG_MEM_GEOM:    r_base <= 32'(mem_geom);
                `FOLDSIM_REG_MEM_WMARK:   r_base <= 32'(mem_wmark);
                `FOLDSIM_REG_MEM_REFI:    r_base <= 32'(mem_refi);
                `FOLDSIM_REG_MEM_RFC:     r_base <= 32'(mem_rfc);
                default:                 r_base <= 32'd0;
                endcase
                r_in_tim <= ar_addr >= `FOLDSIM_REG_MEM_TIMING && ar_addr < `FOLDSIM_REG_MEM_TIMING + 12'(4 * 18);
                r_tim    <= 32'(mem_t[5'((ar_addr - `FOLDSIM_REG_MEM_TIMING) >> 2)]);
                // A port's counters at FOLDSIM_REG_MEM_STATS + 0x40 per port.
                // 32 ports end the window at 0x1000, past 12 bits: compared in 32.
                r_in_stat <= ar_addr >= `FOLDSIM_REG_MEM_STATS && 32'(ar_addr) < 32'(`FOLDSIM_REG_MEM_STATS) + 32'(64 * MEM_PORTS);
                r_stat    <= mem_stats[32'(stat_off[11:6]) * (8 * 64) + 32'(stat_off[5:0]) * 8 +: 32];
                r_in_fin <= ar_addr >= `FOLDSIM_REG_FINISH_BASE
                         && ar_addr < `FOLDSIM_REG_FINISH_BASE + 12'(8 * NUM_CLASSES);
                r_fin    <= ar_addr[2] ? 32'(finishes[fin_idx] >> 32) : finishes[fin_idx][31:0];
                r_in_tel <= (VMEM_TEL_N != 0) && ar_addr >= `FOLDSIM_REG_VMEM_TEL
                         && ar_addr < `FOLDSIM_REG_VMEM_TEL + 12'(8 * 7);
                r_tel    <= ar_addr[2] ? {16'd0, tel_cnt[47:32]} : tel_cnt[31:0];
                r_in_vm <= 1'b0;
                r_vm    <= 32'd0;
                if (VMEM_BYTES != 0) begin
                    r_in_vm <= 1'b1;
                    case ({ar_addr[11:2], 2'b00})
                    `FOLDSIM_REG_VMEM_BYTES:   r_vm <= VMEM_BYTES[31:0];
                    `FOLDSIM_REG_VMEM_BYTES_HI: r_vm <= VMEM_BYTES[63:32];
                    `FOLDSIM_REG_VMEM_BASE_LO: r_vm <= vmem_base[31:0];
                    `FOLDSIM_REG_VMEM_BASE_HI: r_vm <= vmem_base[63:32];
                    default:                   r_in_vm <= 1'b0;
                    endcase
                end
            end
            if (rd_sel) begin
                rd_sel   <= 1'b0;
                s_rvalid <= 1'b1;
                // A port's device-memory telemetry (FOLDSIM_REG_MEM_AXI + 0x20 per port, 24 ports at most) and its
                // stall-reason word (FOLDSIM_REG_MEM_DBG + 4 per port, 32 at most): win_rdata, registered as the read
                // was taken and held until the response.
                s_rdata  <= r_in_vm ? r_vm : r_in_tel ? r_tel : r_in_fin ? r_fin : win_hit ? win_rdata : r_in_stat ? r_stat : r_in_tim ? r_tim : r_base;
            end
            if (s_rvalid & s_rready)
                s_rvalid <= 1'b0;
        end
    end

    // The virtual memories' telemetry: the controller selected.
    if (VMEM_TEL_N != 0) begin : g_tel
        reg [15:0] sel_r;
        always @(posedge clk) begin
            if (reset)
                sel_r <= 16'd0;
            else if (wr & (wa == `FOLDSIM_REG_VMEM_TEL_SEL))
                sel_r <= w_data[15:0];
        end
        assign vmem_tel_sel = sel_r;
    end else begin : g_no_tel
        assign vmem_tel_sel = 16'd0;
    end

    // The virtual memories' region: the runtime places it before the
    // simulator takes a step. Moving it (a write of VMEM_BASE_LO) stops the
    // simulator's requests and has the controllers finish those taken and
    // flush the old region (vmem_move); as a reset, it says nothing of the
    // rows any more: the runtime says again that they are zero once they are
    // (VMEM_ZERO). STATUS bit 4 holds until the controllers are done.
    if (VMEM_BYTES != 0) begin : g_vmem
        reg [63:0] base_r;
        reg        on_r, zero_r, move_r;
        always @(posedge clk) begin
            move_r <= ~reset & wr & (wa == `FOLDSIM_REG_VMEM_BASE_LO);
            if (reset) begin
                base_r <= 64'd0;
                on_r   <= 1'b0;
                zero_r <= 1'b0;
            end else if (wr) begin
                case (wa)
                `FOLDSIM_REG_VMEM_BASE_LO: begin
                    base_r[31:0] <= w_data;
                    on_r         <= 1'b0;
                    zero_r       <= 1'b0;
                end
                `FOLDSIM_REG_VMEM_BASE_HI: begin
                    base_r[63:32] <= w_data;
                    on_r          <= 1'b1;
                end
                `FOLDSIM_REG_VMEM_ZERO:
                    zero_r <= w_data[0];
                default:;
                endcase
            end
        end
        assign vmem_base = base_r;
        assign vmem_on   = on_r;
        assign vmem_zero = zero_r;
        assign vmem_move = move_r;
        // The pulse covers the cycle before the controllers see it.
        assign vmem_busy = move_r | vmem_moving;
    end else begin : g_no_vmem
        /* verilator lint_off UNUSEDSIGNAL */
        wire unused = vmem_moving;
        /* verilator lint_on UNUSEDSIGNAL */
        assign vmem_base = 64'd0;
        assign vmem_on   = 1'b0;
        assign vmem_zero = 1'b0;
        assign vmem_move = 1'b0;
        assign vmem_busy = 1'b0;
    end

endmodule
