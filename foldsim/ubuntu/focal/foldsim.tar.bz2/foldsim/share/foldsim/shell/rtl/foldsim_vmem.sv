// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// A folded simulator's virtual memory: one target RAM's rows for every
// instance, kept in device memory behind an AXI4 512-bit master.
//
// The simulator never waits for the controller: it issues a read or a write
// only when `free` allowed it, and takes a bubble while an instance's read is
// pending. The controller keeps the RAM's semantics and returns each read's
// row tagged with its instance, in any order across instances.
//
// Row `row` of instance `inst` lives at base + ((row * INSTANCES + inst) <<
// log2(ROW_BYTES)), ROW_BYTES a power of two of at least DW/8: one burst of
// ceil(DW/512) beats, which never crosses 4 KiB, or (ROW_BYTES < 64) a part of
// a 64-byte line that other rows share, read as the whole line (the row taken
// out of it) and written with the row's byte strobes only. A row of DW bits
// not whole bytes is kept as whole bytes, the bits above DW zero.
//
// Requests flow in order through four stages:
//   X  the inputs, registered (two cycles more for INSTANCES not a power of
//      two: the multiply; a power of two is a shift); the host cache's tags
//      are read.
//   Y  the read's row against the cache, every buffered write, the write
//      taking a buffer slot this cycle and its own cycle's write: the newest
//      earlier copy of the row. The write hits or fills a cache line, or
//      goes around the cache.
//   Z  a write that goes around, or a dirty line the write evicts, takes a
//      write-buffer slot. The read's match: its slot.
//   R  a read whose newest copy is a whole row, in the cache or the buffer
//      (the buffer only with FORWARD),
//      answers from it; any other read joins the read queue, waiting first
//      for the B of the newest write of its row still on its way to memory.
// Writes leave the buffer in order on AW and W (one AXI id, so their B's
// come back in order) and free their slot with their last W beat: up to
// WRITES_OUT of them then wait for B outside the buffer, so the buffer's
// depth does not bound the writes in flight. AXI orders no read after a
// write, so a read must not reach AR before the B of an earlier write of its
// row: each write has a sequence number (taken at Z, B's come in its order),
// and a hazard table, indexed by a hash of the row, keeps the newest write's
// number per entry. A read whose row has a write in the buffer depends on
// that write (it is the newest); any other depends on its entry's number
// while that write has no B yet (another row's newer write sharing the entry
// only makes it wait longer). Reads leave the read queue in order on AR, up
// to OUTSTANDING of them, the ids taken in turn: AXI answers one id's reads
// in order, so each id keeps its reads in a ring, and R (any order and
// interleaved across ids) answers the oldest of its id with its last beat.
//
// The host cache (CACHE_ROWS > 0, up to a line per row) is direct-mapped and
// write-back, indexed by the low bits of row * INSTANCES + inst (consecutive
// instances, consecutive lines). A whole-row write allocates without a fetch,
// a read-first pair's too (its read still gets the old row, from the buffer
// or memory); a partial write hits or goes around. A read that misses goes to
// memory, and its answer fills the line, clean, unless the line holds a dirty
// row (a fill takes the place of a write at X, in a cycle without one; a
// write of its row getting there first drops it). A pair's read fills
// nothing: its write is newer.
// Such a pair leaves its new row in the cache while its read fetches the old
// one: until that read has its data, the line must not reach memory. Only a
// write's allocation (or a reset's sweep, after which no read answers) evicts
// a dirty line, and an instance with a read outstanding writes nothing. So
// where every line belongs to one instance (INSTANCES a power of two, at most
// CACHE_ROWS; or a line per row), the line is safe by construction. Elsewhere
// the pair pins its line (a few pins, else it goes around as below) until the
// read has its data, and a write whose line is pinned goes around the cache
// instead. A pair that goes around waits in the buffer for its read.
//
// Request-queue room (`free`): a read holds an entry from the cycle it is
// taken until it answers locally or goes out on AR; a write until it is in
// the cache, or until the slot it (or the line it evicts) takes is freed by
// its last W beat. A slot is so never freed while a read between X and R may
// still answer from it (the read holds room, so the buffer is not full and
// the tail cannot come round to it).
//
// Known-zero rows (KNOWN_ZERO): a bit per row of the image says whether a
// write took the row since the reset. While `zero` is high -- the host says
// memory holds zero in every row not written since the reset, as a runtime
// that cleared the image does -- a row not written is zero: a read of it is
// answered on chip (zeros, like a cache hit, filling no line: the bit already
// answers it), and a write of it is made whole, zeros where its mask is off,
// so it may fill a line and memory's copy of the row no longer matters. A
// read-first pair's read sees the row before its write. The bits are looked
// up as requests are taken, so they follow request order; the reset clears
// them, a word of each of KBANKS one-bit memories a cycle, within its drain.
// With `zero` low the controller behaves as without the bits. A bit may stand
// for a block of 2^KZ_SHIFT consecutive rows of the image (row * INSTANCES +
// inst), written since the reset once any of its rows is: the others are
// still zero in memory, so only the rows of untouched blocks are known zero.
//
// Reset takes no request, drops every read not yet on AR and answers none
// from before it; every write taken before it still goes to the cache or
// memory, and then every dirty line goes to memory and every line is
// invalidated: memory holds the RAM's image (which the host may then change).
// It finishes, with free back at QUEUE, once memory has answered every
// transaction (every write's B included): until then free stays 0.
//
// With TAGW tag bits (foldsim_vmem_group), rd_inst and wr_inst carry a member
// tag above the instance: the response returns it, the address ignores it (the
// group gives its members disjoint rows), and the simulator's guarantees hold
// per (tag, instance).
//
// A region move (`move`, the host placing the image elsewhere, as a new
// process does without a reset) ends the old region's use as a reset does,
// but the simulator keeps its state: free drops to 0 and `moving` rises;
// every request taken before it, or within the simulator's lead after it, is
// served and answered against the old region (no fill); then, once no request
// has come for QUIET cycles and none is in flight, the cache's sweep writes
// every dirty line back to the old base and invalidates every line, and the
// known-zero bits are cleared. Once memory has answered every transaction,
// `moving` falls, free returns to QUEUE and the new base takes effect. The
// base the controller uses is held from `move` (and from a reset) until then.
module foldsim_vmem #(
    // Instance-index bits: the global instance index over all copies.
    parameter IW             = 8,
    // Row-address bits.
    parameter AW             = 10,
    // Row data bits, up to 4096: any width with a whole-row enable (MW = 1),
    // else a multiple of 8.
    parameter DW             = 512,
    // Mask bits: DW/8 byte enables, or 1 for a whole-row enable. A bit
    // enables DW/8/MW bytes.
    parameter MW             = DW / 8,
    // A same-cycle read of the row being written returns the old row (1) or
    // the new one (0).
    parameter RDW_READ_FIRST = 1,
    // Request-queue entries.
    parameter QUEUE          = 32,
    parameter AXI_ID_W       = 4,
    // Reads on AXI at once, a power of two: each id (2^AXI_ID_W of them, or
    // fewer) carries OUTSTANDING / ids of them, in order.
    parameter OUTSTANDING    = 16,
    // The instances the layout spaces rows by.
    parameter INSTANCES      = 1 << IW,
    // Host-cache rows, a power of two up to 2^(AW + clog2(INSTANCES)), a
    // line per row (0: direct).
    parameter CACHE_ROWS     = 0,
    // Known-zero rows: a bit per row of the image (0: none, `zero` unused),
    // or per block of 2^KZ_SHIFT rows.
    parameter KNOWN_ZERO     = 1,
    parameter KZ_SHIFT       = 0,
    // A row's bytes in memory: a power of two of at least DW/8 (below 64,
    // rows share 64-byte lines).
    parameter ROW_BYTES      = (((DW + 7) / 8) > 64) ? (1 << $clog2((DW + 7) / 8)) : 64,
    // Tag bits above the instance index in rd_inst, wr_inst and rsp_inst
    // (foldsim_vmem_group's member): carried to the response, never part of
    // the address. Requests of different tags may share lines, so read-first
    // pairs pin theirs wherever lines are not one per row; and the cache's
    // index hashes the row's high bits in, so members using the same rows of
    // their own do not take the same lines.
    parameter TAGW           = 0,
    // Writes on AXI waiting for their B at once, out of the buffer.
    parameter WRITES_OUT     = 128,
    // The hazard table's entries, log2 (at most the image's rows): a hash of
    // a row to the newest write number. More entries, fewer reads that wait
    // for another row's write.
    parameter HAZARD_BITS    = $clog2(QUEUE + WRITES_OUT) + 3,
    // Write-number bits: more than the writes in flight need, so that a
    // number left in the table long ago rarely looks in flight again (it
    // then only makes a read wait for a write's B).
    parameter SEQ_W          = 16,
    // Reads answered from the write buffer (1), or never (0): a read whose
    // newest copy is a buffered write then goes to memory once that write
    // has its B, as a read of a partly written row does. The buffer is then
    // read by the W channel alone (one read port, half its distributed RAM);
    // for an image whose static order puts a row's read long after its write
    // (page engines, link streams, folds of long frames), nothing waits.
    parameter FORWARD        = 1,
    // Telemetry counters (`tel`), TEL_N of TEL_W bits each, from the reset:
    // [0] reads taken, [1] writes taken, [2] reads answered on chip (cache,
    // write buffer, known-zero row), [3] row fetches (AR), [4] write-backs
    // (AW), [5] host cycles with no room for the simulator (free == 0),
    // [6] host cycles with a read on AXI. 0: none (`tel` reads zero).
    parameter TELEMETRY      = 1,
    localparam TEL_N         = 7,
    localparam TEL_W         = 48
) (
    input  wire                        clk,
    input  wire                        reset,

    input  wire                        rd_valid,
    input  wire [IW+TAGW-1:0]          rd_inst,
    input  wire [AW-1:0]               rd_row,

    input  wire                        wr_valid,
    input  wire [IW+TAGW-1:0]          wr_inst,
    input  wire [AW-1:0]               wr_row,
    input  wire [DW-1:0]               wr_data,
    input  wire [MW-1:0]               wr_mask,

    output wire                        rsp_valid,
    output reg  [IW+TAGW-1:0]          rsp_inst,
    output wire [DW-1:0]               rsp_data,

    output reg  [$clog2(QUEUE+1)-1:0]  free,

    input  wire [63:0]                 base,
    // Memory holds zero in every row not written since the reset.
    input  wire                        zero,
    // A cycle's pulse: the region moves; `base` may change from this cycle on.
    input  wire                        move,
    // The move is under way (from the cycle after `move`).
    output wire                        moving,

    output reg                         m_awvalid,
    input  wire                        m_awready,
    output reg  [63:0]                 m_awaddr,
    output wire [AXI_ID_W-1:0]         m_awid,
    output wire [7:0]                  m_awlen,
    output reg                         m_wvalid,
    input  wire                        m_wready,
    output reg  [511:0]                m_wdata,
    output reg  [63:0]                 m_wstrb,
    output reg                         m_wlast,
    input  wire                        m_bvalid,
    output wire                        m_bready,
    /* verilator lint_off UNUSEDSIGNAL */
    input  wire [AXI_ID_W-1:0]         m_bid,
    /* verilator lint_on UNUSEDSIGNAL */
    output reg                         m_arvalid,
    input  wire                        m_arready,
    output reg  [63:0]                 m_araddr,
    output reg  [AXI_ID_W-1:0]         m_arid,
    output wire [7:0]                  m_arlen,
    input  wire                        m_rvalid,
    output reg                         m_rready,
    input  wire [511:0]                m_rdata,
    input  wire [AXI_ID_W-1:0]         m_rid,
    /* verilator lint_off UNUSEDSIGNAL */
    input  wire                        m_rlast,
    /* verilator lint_on UNUSEDSIGNAL */

    // The telemetry counters, counter c at [c * TEL_W +: TEL_W].
    output wire [TEL_N*TEL_W-1:0]      tel
);
    localparam FW     = $clog2(QUEUE + 1);
    localparam IT     = IW + TAGW;
    localparam QW     = (QUEUE > 1) ? $clog2(QUEUE) : 1;
    localparam OW     = (OUTSTANDING > 1) ? $clog2(OUTSTANDING) : 1;
    // The ids in use and their reads in flight each: a read's slot of the
    // tables is {its place in its id's ring, its id}.
    // A controller that answers no read on chip (no host cache, no
    // known-zero rows, no forwarding: a page engine, a link stream) with rows
    // of several beats reads on one id: its bursts come back whole, in order,
    // each beat straight into the answer's row (no row of beats per id).
    localparam DIRECT = (CACHE_ROWS == 0) && (KNOWN_ZERO == 0) && (FORWARD == 0) && ((DW + 7) / 8 > 64);
    localparam NID    = DIRECT ? 1 : ((1 << AXI_ID_W) < OUTSTANDING) ? (1 << AXI_ID_W) : OUTSTANDING;
    localparam IDW    = (NID > 1) ? $clog2(NID) : 1;
    localparam DEPTH  = OUTSTANDING / NID;
    localparam DPW    = (DEPTH > 1) ? $clog2(DEPTH) : 1;
    localparam LNID   = $clog2(NID);
    localparam KB     = $clog2(INSTANCES);
    localparam POW2   = ((INSTANCES & (INSTANCES - 1)) == 0) ? 1 : 0;
    localparam LW     = AW + KB;
    // The row in whole bytes.
    localparam DB     = (DW + 7) / 8 * 8;
    localparam BYTES  = DB / 8;
    localparam RB     = $clog2(ROW_BYTES);
    // Rows sharing a 64-byte line (SUB); a row's place in its line, in bits.
    localparam SUB    = (RB < 6) ? 1 : 0;
    localparam SLW    = (RB < 6) ? 6 - RB : 1;
    localparam BEATS  = (DB + 511) / 512;
    localparam BW     = (BEATS > 1) ? $clog2(BEATS) : 1;
    localparam GROUP  = BYTES / MW;
    // A row's offset in the image: its bits.
    localparam OB     = LW + RB;
    localparam CACHE  = (CACHE_ROWS > 0) ? 1 : 0;
    // A line's index and tag bits.
    localparam CI     = (CACHE_ROWS > 1) ? $clog2(CACHE_ROWS) : 1;
    localparam CT     = (LW > CI) ? LW - CI : 1;
    // Lines shared by instances (a line holds rows of one instance when
    // INSTANCES is a power of two, at most CACHE_ROWS, or when every row has
    // a line): read-first pairs pin theirs (PINS at once).
    localparam PIN    = (CACHE != 0) && (CACHE_ROWS < (1 << AW) * INSTANCES)
                     && (POW2 == 0 || CACHE_ROWS < INSTANCES || TAGW > 0);
    localparam PINS   = 8;
    localparam PW     = $clog2(PINS);
    localparam KZ     = (KNOWN_ZERO != 0) ? 1 : 0;
    // A move's flush starts once no request has come for this many cycles:
    // past the simulator's lead (L = 4) after free dropped to 0.
    localparam QUIET  = 15;
    // A line's index: the row's low bits, with (TAGW > 0) the bits above them
    // XORed in, CI at a time from the top: the tag's top bits reach the
    // index's top bits, so members (largest first, each at a multiple of its
    // size) using their low rows alike take different parts of the cache. The
    // tag keeps the bits above, so the row is {tag, index ^ fold(tag)}.
    localparam HASH   = (TAGW > 0) && (CACHE != 0) && (LW > CI);
    localparam HPAD   = (CI - (CT % CI)) % CI;
    // Writes taken and without a B (in the buffer or on AXI), their count's
    // bits; writes on AXI, their count's bits.
    localparam NFW    = $clog2(QUEUE + WRITES_OUT + 1);
    // A queued read's write (taken, no B yet) is among the NFW-bit count of
    // writes without a B: its number's low DSW bits name it among them, so
    // the queue compares those alone with each B's.
    localparam DSW    = (NFW + 1 < SEQ_W) ? NFW + 1 : SEQ_W;
    localparam NAW    = $clog2(WRITES_OUT + 1);
    // The hazard table: entries, index bits (the row itself when it fits).
    localparam HZW    = (HAZARD_BITS < LW) ? HAZARD_BITS : LW;
    localparam HZ     = 1 << HZW;

    // Where a local answer's row comes from.
    localparam SRC_WB = 2'd0;  // the write buffer
    localparam SRC_CA = 2'd1;  // the cache, by the read's own port
    localparam SRC_CB = 2'd2;  // the cache line the same-cycle write reads first
    localparam SRC_ZR = 2'd3;  // a known-zero row

`ifdef SIMULATION
    initial begin
        if (DW < 1 || DW > 4096 || ((DW % 8) != 0 && MW != 1))
            $error("foldsim_vmem: DW must be 1 to 4096 bits, a multiple of 8 with byte enables");
        if ((BYTES % MW) != 0)
            $error("foldsim_vmem: MW must divide DW/8");
        if (OUTSTANDING < 1 || (OUTSTANDING & (OUTSTANDING - 1)) != 0)
            $error("foldsim_vmem: OUTSTANDING must be a power of two");
        if ((ROW_BYTES & (ROW_BYTES - 1)) != 0 || ROW_BYTES < BYTES)
            $error("foldsim_vmem: ROW_BYTES must be a power of two of at least DW/8");
        if (KZ_SHIFT < 0 || KZ_SHIFT >= LW)
            $error("foldsim_vmem: KZ_SHIFT must be below the image's row bits");
        if (INSTANCES > (1 << IW))
            $error("foldsim_vmem: INSTANCES exceeds the instance index");
        if (QUEUE < 10)
            $error("foldsim_vmem: QUEUE must be at least 10, the simulator's room (VMEM_INTERFACE.md guarantee 2)");
        if (CACHE_ROWS != 0 && (CACHE_ROWS < 2 || (CACHE_ROWS & (CACHE_ROWS - 1)) != 0 || CI > LW))
            $error("foldsim_vmem: CACHE_ROWS must be a power of two, at most 2^(AW + clog2(INSTANCES))");
        if (WRITES_OUT < 1 || HAZARD_BITS < 1)
            $error("foldsim_vmem: WRITES_OUT and HAZARD_BITS must be at least 1");
        if (SEQ_W <= NFW)
            $error("foldsim_vmem: SEQ_W must exceed the bits of QUEUE + WRITES_OUT");
    end
`endif

    function automatic [QW-1:0] qinc(input [QW-1:0] p);
        qinc = (p == QW'(QUEUE - 1)) ? '0 : p + 1'b1;
    endfunction

    function automatic [QW-1:0] onehot_index(input [QUEUE-1:0] v);
        onehot_index = '0;
        for (integer i = 0; i < QUEUE; ++i)
            if (v[i])
                onehot_index = onehot_index | QW'(i);
    endfunction

    // A read's slot of the tables: its place in its id's ring, and its id.
    function automatic [OW-1:0] tag_of(input [DPW-1:0] place, input [IDW-1:0] id);
        tag_of = OW'((32'(place) & (DEPTH - 1)) << LNID) | OW'(32'(id) & (NID - 1));
    endfunction

    function automatic [CI-1:0] fold(input [LW-1:0] hi);
        reg [LW+CI-1:0] t;
        t    = (LW+CI)'(hi) << HPAD;
        fold = '0;
        for (integer c = 0; c < LW + CI; c += CI)
            fold = fold ^ CI'(t >> c);
    endfunction
    function automatic [CI-1:0] cidx(input [LW-1:0] lin);
        cidx = (HASH != 0) ? (lin[CI-1:0] ^ fold(lin >> CI)) : lin[CI-1:0];
    endfunction

    // A row's hazard-table entry: its low bits, the rest XORed in (rows a
    // fixed distance apart do not keep meeting in one entry).
    function automatic [HZW-1:0] hidx(input [LW-1:0] lin);
        reg [LW+HZW-1:0] t;
        t    = (LW+HZW)'(lin);
        hidx = '0;
        for (integer c = 0; c < LW; c += HZW)
            hidx = hidx ^ HZW'(t >> c);
    endfunction

    function automatic [BYTES-1:0] byte_enables(input [MW-1:0] mask);
        for (integer j = 0; j < BYTES; ++j)
            byte_enables[j] = mask[j / GROUP];
    endfunction

    // ---- State that outlives a reset: what the cache and memory have, or
    // are owed ----
    // A reset drains it rather than clearing it, so it starts at its
    // power-up value: 0, as the FPGA's flops and block RAMs (INIT 0) do.
    // Simulation starts it there too.
    reg              draining;
    reg              x_wr, y_wr, x_sw, y_sw, x_fl, y_fl, z_wa, z_ev;
    reg [QUEUE-1:0]  wb_valid;
    reg [QW-1:0]     wb_tail, wb_aw, wb_w;
    // Writes in the buffer: all, before AW, before their last W beat; out of
    // it, before B.
    reg [FW-1:0]     wb_cnt, n_aw, n_w;
    reg [NAW-1:0]    n_b;
    // Write numbers: the next taken, the next B's; writes taken without a B,
    // and on AXI without a B.
    reg [SEQ_W-1:0]  w_seq, b_seq;
    reg [NFW-1:0]    n_fl;
    reg [NAW-1:0]    n_ab;
    reg [BW-1:0]     w_beat;
    // Each id's reads in flight, its ring's oldest and next slots; the id
    // the next read takes; reads in flight in all.
    reg [DPW:0]      id_cnt  [NID];
    reg [DPW-1:0]    id_head [NID];
    reg [DPW-1:0]    id_tail [NID];
    reg [IDW-1:0]    ar_rr;
    reg [OW:0]       rd_out;
    reg              rc_valid;
    reg [63:0]       base_q;
`ifdef SIMULATION
    initial begin
        base_q    = '0;
        draining  = 1'b0;
        x_wr      = 1'b0;
        y_wr      = 1'b0;
        x_sw      = 1'b0;
        y_sw      = 1'b0;
        x_fl      = 1'b0;
        y_fl      = 1'b0;
        z_wa      = 1'b0;
        z_ev      = 1'b0;
        wb_valid  = '0;
        wb_tail   = '0;
        wb_aw     = '0;
        wb_w      = '0;
        wb_cnt    = '0;
        n_aw      = '0;
        n_w       = '0;
        n_b       = '0;
        w_seq     = '0;
        b_seq     = '0;
        n_fl      = '0;
        n_ab      = '0;
        w_beat    = '0;
        for (integer i = 0; i < NID; ++i) begin
            id_cnt[i]  = '0;
            id_head[i] = '0;
            id_tail[i] = '0;
        end
        ar_rr     = '0;
        rd_out    = '0;
        rc_valid  = 1'b0;
        m_awvalid = 1'b0;
        m_wvalid  = 1'b0;
        m_arvalid = 1'b0;
    end
`endif

    if (TAGW > 0) begin : g_tag
        // A write's tag only names its member, for the checks below.
        /* verilator lint_off UNUSEDSIGNAL */
        wire unused = |wr_inst[IT-1:IW];
        /* verilator lint_on UNUSEDSIGNAL */
    end

    wire accept = ~reset & ~draining;
    wire taken_rd = rd_valid & accept;
    wire taken_wr = wr_valid & accept;
    // A B: always ready.
    wire b_pop    = m_bvalid;

    // ---- Intake: a row's index in the image, row * INSTANCES + inst ----
    // i_busy, i_rbusy: a write, a read, still in the multiply.
    wire              i_rd, i_wr, i_busy, i_rbusy;
    wire [IT-1:0]     i_rinst;
    wire [LW-1:0]     i_rlin, i_wlin;
    wire [DB-1:0]     i_wdata;
    wire [MW-1:0]     i_wmask;
    if (POW2 != 0) begin : g_lin_shift
        // inst < INSTANCES: its low KB bits.
        assign i_rd    = taken_rd;
        assign i_wr    = taken_wr;
        assign i_busy  = 1'b0;
        assign i_rbusy = 1'b0;
        assign i_rinst = rd_inst;
        assign i_rlin  = (LW'(rd_row) << KB) | LW'(rd_inst[IW-1:0] & IW'(INSTANCES - 1));
        assign i_wlin  = (LW'(wr_row) << KB) | LW'(wr_inst[IW-1:0] & IW'(INSTANCES - 1));
        assign i_wdata = DB'(wr_data);
        assign i_wmask = wr_mask;
    end else begin : g_lin_mul
        // The multiply in a DSP, its input and product registered: two more
        // cycles. A write taken still reaches the cache or memory through a
        // reset.
        reg          a_rd, a_wr, p_rd, p_wr;
        reg [AW-1:0] a_rrow, a_wrow;
        reg [IT-1:0] a_rinst, p_rinst;
        reg [IW-1:0] a_winst, p_winst;
        reg [LW-1:0] p_rprod, p_wprod;
        reg [DB-1:0] a_wdata, p_wdata;
        reg [MW-1:0] a_wmask, p_wmask;
`ifdef SIMULATION
        initial begin
            a_wr = 1'b0;
            p_wr = 1'b0;
            a_rd = 1'b0;
            p_rd = 1'b0;
        end
`endif
        always @(posedge clk) begin
            a_rd    <= taken_rd;
            a_wr    <= taken_wr;
            a_rrow  <= rd_row;
            a_wrow  <= wr_row;
            a_rinst <= rd_inst;
            a_winst <= wr_inst[IW-1:0];
            a_wdata <= DB'(wr_data);
            a_wmask <= wr_mask;
            p_rd    <= a_rd & ~reset;
            p_wr    <= a_wr;
            p_rprod <= LW'(a_rrow) * LW'(INSTANCES);
            p_wprod <= LW'(a_wrow) * LW'(INSTANCES);
            p_rinst <= a_rinst;
            p_winst <= a_winst;
            p_wdata <= a_wdata;
            p_wmask <= a_wmask;
        end
        assign i_rd    = p_rd;
        assign i_wr    = p_wr;
        assign i_busy  = a_wr | p_wr;
        assign i_rbusy = a_rd | p_rd;
        assign i_rinst = p_rinst;
        assign i_rlin  = p_rprod + LW'(p_rinst[IW-1:0]);
        assign i_wlin  = p_wprod + LW'(p_winst);
        assign i_wdata = p_wdata;
        assign i_wmask = p_wmask;
    end

    // The base in use (base_q): `base` but through a reset's drain and a
    // move, which still address the old region; taken again as either ends.
    // base + offset adds only the offset's bits; above them, base or base + 1
    // (kept registered: base is static while requests flow).
    reg [63-OB:0] base_hi1;
    wire          base_hold;
    always @(posedge clk) begin
        if (~base_hold)
            base_q <= base;
        base_hi1 <= base_q[63:OB] + 1'b1;
    end
    function automatic [63:0] row_addr(input [LW-1:0] lin);
        reg [OB:0] lo;
        lo = {1'b0, base_q[OB-1:0]} + {1'b0, lin, {RB{1'b0}}};
        row_addr = {lo[OB] ? base_hi1 : base_q[63:OB], lo[OB-1:0]};
    endfunction

    // ---- The sweep of a reset's drain: every line, in order ----
    reg              sw_done;
    reg [CI-1:0]     sw_idx;
    wire             sweep_go;

    // ---- A fill: a row memory answered, for its line ----
    // It takes the write's place at X in a cycle without one. A write of its
    // row reaching X first would be newer (only the read's instance writes
    // the row, after its answer): the fill is dropped then.
    wire             fl_v;
    wire [LW-1:0]    fl_lin;
    wire [DB-1:0]    fl_data;
    // A move (mv_busy) fills nothing either: its sweep empties the cache.
    reg              mv_busy;
    wire             fill_go = fl_v & ~i_wr & ~reset & ~draining & ~mv_busy;

    // ---- Known-zero rows: looked up as requests are taken ----
    // At X: the write's row, the read's row was zero before this cycle's
    // write (zero high, no write since the reset); the reset's clear is done.
    wire             kz_w, kz_r, kz_done;

    // ---- A move: its flush (the sweep and the clear) has begun, begins ----
    reg              mv_flush;
    wire             mv_go;
`ifdef SIMULATION
    initial begin
        mv_busy  = 1'b0;
        mv_flush = 1'b0;
    end
`endif

    // ---- X: the requests, in the image's terms; the tags are read ----
    reg              x_rd;
    reg [IT-1:0]     x_rinst;
    reg [LW-1:0]     x_rlin, x_wlin;
    reg [DB-1:0]     x_wdata;
    reg [MW-1:0]     x_wmask;
    reg [CI-1:0]     x_swidx;

    always @(posedge clk) begin
        x_rd    <= i_rd & ~reset;
        x_wr    <= i_wr;
        x_sw    <= sweep_go;
        x_fl    <= fill_go;
        x_swidx <= sw_idx;
        x_rinst <= i_rinst;
        x_rlin  <= i_rlin;
        x_wlin  <= fill_go ? fl_lin : i_wlin;
        x_wdata <= fill_go ? fl_data : i_wdata;
        x_wmask <= fill_go ? '1 : i_wmask;
    end

    // A write of a known-zero row, made whole: zeros where its mask is off.
    reg [DB-1:0] x_wzdata;
    always @(*) begin
        for (integer j = 0; j < BYTES; ++j)
            x_wzdata[j*8 +: 8] = (kz_w & ~x_wmask[j / GROUP]) ? 8'd0 : x_wdata[j*8 +: 8];
    end
    // The read's row is zero: a known-zero row, but a write-first pair's
    // (its own write is newer); a pair's read sees the row before its write.
    wire x_same = x_rd & x_wr & (x_rlin == x_wlin);
    wire x_zero = x_rd & (x_same ? ((RDW_READ_FIRST != 0) & kz_w) : kz_r);

    // ---- Y: the newest earlier copy of the read's row ----
    reg              y_rd, y_wfull, y_zero;
    // The hazard table's number for the read's row (looked up at X), and the
    // next number then: only a write numbered below it is older than the read.
    reg [SEQ_W-1:0]  y_hz, y_lim;
    reg [IT-1:0]     y_rinst;
    reg [LW-1:0]     y_rlin, y_wlin;
    reg [DB-1:0]     y_wdata;
    reg [MW-1:0]     y_wmask;
    reg [CI-1:0]     y_swidx;
    reg [63:0]       y_raddr;

    always @(posedge clk) begin
        y_rd    <= x_rd & ~reset;
        y_zero  <= x_zero & ~reset;
        y_wr    <= x_wr;
        y_sw    <= x_sw;
        y_fl    <= x_fl;
        y_swidx <= x_swidx;
        y_rinst <= x_rinst;
        y_rlin  <= x_rlin;
        y_wlin  <= x_wlin;
        y_wdata <= x_wzdata;
        y_wmask <= x_wmask | {MW{kz_w}};
        y_wfull <= (&x_wmask) | kz_w;
        y_raddr <= row_addr(x_rlin);
    end

    // The hazard table: each write taking a slot (at Z) leaves its number at
    // its row's entry; a read looks its row's up at X. A write taking a slot
    // in the cycles between is still in the buffer when the read is at Y. A
    // number in it outlives a reset or a move (its B came back by their end).
    reg [SEQ_W-1:0] hz [HZ];
`ifdef SIMULATION
    initial begin
        for (integer i = 0; i < HZ; ++i)
            hz[i] = '0;
    end
`endif
    always @(posedge clk) begin
        y_hz  <= hz[hidx(x_rlin)];
        y_lim <= w_seq;
        if (z_alloc)
            hz[hidx(z_alin)] <= w_seq;
    end
    // The entry names a write taken before the read's lookup and without a
    // B, not even this cycle's (else it is stale, or names a later write: the
    // read must not wait for that, which may itself wait for a read behind
    // this one).
    wire y_hzdep = ((y_hz - b_seq) < (y_lim - b_seq)) & ~(b_pop & (y_hz == b_seq));

    // The cache's view at Y, and its rows at Z and R. c_victim: the write's
    // line holds a dirty row.
    wire             c_rhit, c_whit, c_victim, c_same_idx;
    wire [CT-1:0]    c_vtag;
    wire [DB-1:0]    c_ca, c_cb;

    wire y_same_row = y_rd & y_wr & (y_rlin == y_wlin);
    wire rf_pair    = y_same_row & (RDW_READ_FIRST != 0);
    // Pins (PIN): the write's line is pinned; a pin is free, and which.
    wire          y_pinned, pin_room;
    wire [PW-1:0] pin_next;
    // A whole-row write fills a line, but over a pinned line, or a read-first
    // pair's with no pin free: those go around.
    wire w_alloc  = (CACHE != 0) & y_wr & ~c_whit & y_wfull
                  & ~(PIN & (y_pinned | (rf_pair & ~pin_room)));
    wire w_around = y_wr & ~c_whit & ~w_alloc;
    // A read-first pair filling a shared line pins it until its read has its
    // data.
    wire y_pin    = PIN & rf_pair & w_alloc;
    wire evict    = (w_alloc | y_sw) & c_victim;
    // A fill takes a line that holds no dirty row (no write-back, no pin).
    wire f_alloc  = (CACHE != 0) & y_fl & ~c_victim;
    wire [CI-1:0] y_widx = y_sw ? y_swidx : cidx(y_wlin);
    wire [LW-1:0] ev_lin = (HASH != 0) ? LW'({c_vtag, y_widx ^ fold(LW'(c_vtag))}) : LW'({c_vtag, y_widx});
    // The write is done with the cache: its room is free.
    wire y_wdone  = y_wr & ~w_around & ~evict;

    // The read's own write, around the cache: seen by it, or held until it
    // has its data.
    wire pair_wf  = y_same_row & w_around & (RDW_READ_FIRST == 0);
    wire pair_rf  = rf_pair & w_around;
    // In the cache: a hit, or a write-first pair's line.
    wire c_local  = c_rhit | (y_same_row & w_alloc & (RDW_READ_FIRST == 0));

    // The write buffer: writes in request order, until their B. A write is
    // live until a later write of its row takes a slot, so a row has at most
    // one live write: a read's match needs no priority.
    // (wb_lin, wb_live: read only with FORWARD.)
    /* verilator lint_off UNUSEDSIGNAL */
    reg [LW-1:0]     wb_lin  [QUEUE];
    reg [QUEUE-1:0]  wb_live;
    /* verilator lint_on UNUSEDSIGNAL */
    reg [QUEUE-1:0]  wb_full, wb_blk;
    reg [SEQ_W-1:0]  wb_seq  [QUEUE];
    reg [DB-1:0]     wb_data [QUEUE];
    reg [MW-1:0]     wb_mask [QUEUE];
    reg [63:0]       wb_addr [QUEUE];

    reg              z_rd, z_local, z_pair, z_zhit, z_ub, z_merge, z_wfull, z_blk, z_pin, z_fill;
    reg [LW-1:0]     z_rlin;
    reg [PW-1:0]     z_pinid;
    reg [1:0]        z_src;
    reg [QUEUE-1:0]  z_hit;
    reg              z_phit;
    reg [SEQ_W-1:0]  z_pseq;
    reg [QW-1:0]     z_zslot;
    reg [SEQ_W-1:0]  z_zseq, z_hz;
    reg              z_hzdep;
    reg [IT-1:0]     z_rinst;
    reg [63:0]       z_raddr;
    reg [LW-1:0]     z_alin;
    reg [DB-1:0]     z_wdata;
    reg [MW-1:0]     z_wmask;

    wire z_alloc = z_wa | z_ev;
    wire z_afull = z_ev | z_wfull;

    // A read's newest buffered write of its row (rhit). Without forwarding
    // (FORWARD 0) the buffer answers no read: a read needs only the number of
    // the newest write of its row without a B, which the hazard table gives
    // for the writes that took a slot before the read's lookup (at X; a
    // newer write of another row in its entry only makes the read wait
    // longer), the write taking a slot in the lookup's cycle (p_*, compared
    // at Y) and the one taking a slot at Y (zhit). So the buffer keeps no
    // rows and no match (wb_lin, wb_live: a compare of every slot at Y and
    // at Z).
    wire [QUEUE-1:0] rhit;
    reg             p_v;
    reg [LW-1:0]    p_lin;
    reg [SEQ_W-1:0] p_seq;
    wire            phit = p_v & (p_lin == y_rlin);
    if (FORWARD != 0) begin : g_rhit
        for (genvar i = 0; i < QUEUE; ++i) begin : g_slot
            assign rhit[i] = wb_valid[i] & wb_live[i] & (wb_lin[i] == y_rlin);
        end
    end else begin : g_no_rhit
        assign rhit = '0;
    end
`ifdef SIMULATION
    initial p_v = 1'b0;
`endif
    always @(posedge clk) begin
        p_v   <= z_alloc;
        p_lin <= z_alin;
        p_seq <= w_seq;
    end
    // The write taking a slot this cycle is newer than the buffer's.
    wire zhit   = z_alloc & (z_alin == y_rlin);
    wire wb_fwd = (FORWARD != 0) & (pair_wf ? y_wfull : (zhit ? z_afull : |(rhit & wb_full)));
    wire y_local = (y_rd & (c_local | wb_fwd)) | y_zero;
    wire [1:0] y_src = y_zero ? SRC_ZR
                     : ~c_local ? SRC_WB
                     : ((c_same_idx & (c_whit | w_alloc | f_alloc)) ? SRC_CB : SRC_CA);
    // A read that goes to memory fills its line with the answer, but a
    // pair's: its write is newer.
    wire y_fill = (CACHE != 0) & ~y_same_row;

    always @(posedge clk) begin
        z_rd    <= y_rd & ~reset;
        z_local <= y_local & ~reset;
        z_src   <= y_src;
        z_merge <= y_same_row & (RDW_READ_FIRST == 0);
        z_hit   <= rhit;
        z_phit  <= (FORWARD == 0) & phit;
        z_pseq  <= p_seq;
        z_pair  <= pair_wf;
        z_zhit  <= zhit;
        z_zslot <= wb_tail;
        z_zseq  <= w_seq;
        z_hz    <= y_hz;
        z_hzdep <= y_hzdep;
        z_ub    <= pair_rf;
        z_pin   <= y_pin;
        z_pinid <= pin_next;
        z_fill  <= y_fill;
        z_rlin  <= y_rlin;
        z_rinst <= y_rinst;
        z_raddr <= y_raddr;
        z_wa    <= w_around;
        z_ev    <= evict;
        z_alin  <= evict ? ev_lin : y_wlin;
        z_wdata <= y_wdata;
        z_wmask <= y_wmask;
        z_wfull <= y_wfull;
        z_blk   <= pair_rf;
        // R's last beat answers a read the cycle after it: never in the cycle
        // a read answers locally.
        m_rready <= ~(y_local & ~reset);
    end

    // ---- Z: a write around the cache, or an evicted line, takes a slot ----
    // A slot valid at Y is not taken again before R ends (the read holds
    // room, so the buffer is not full), so its data is still the matched
    // write's.
    // (Without a cache the buffer takes the row at X or at intake: g_xdata.)
    /* verilator lint_off UNUSEDSIGNAL */
    wire [DB-1:0]    z_adata = z_ev ? c_cb : z_wdata;
    wire [MW-1:0]    z_amask = z_ev ? '1 : z_wmask;
    /* verilator lint_on UNUSEDSIGNAL */
    wire [63:0]      z_aaddr = row_addr(z_alin);
    wire [QW-1:0]    z_slot  = z_pair ? wb_tail : (z_zhit ? z_zslot : onehot_index(z_hit));
    // The write a read going to memory waits for (its B), if it has none
    // yet: its row's in the buffer, the newest (a write-first pair's own
    // write takes its slot now); else its hazard entry's, if older than it.
    // (FORWARD 0: the hazard table's, the last cycle's slot, or this one's.)
    wire             z_buf   = z_pair | z_zhit | (|z_hit) | z_phit;
    wire [SEQ_W-1:0] z_dseq  = z_pair ? w_seq : z_zhit ? z_zseq : (|z_hit) ? wb_seq[onehot_index(z_hit)]
                             : z_phit ? z_pseq : z_hz;

    wire [QUEUE-1:0] whit;
    if (FORWARD != 0) begin : g_whit
        for (genvar i = 0; i < QUEUE; ++i) begin : g_slot
            assign whit[i] = wb_valid[i] & (wb_lin[i] == z_alin);
        end
    end else begin : g_no_whit
        assign whit = '0;
    end

    // A write-first pair's line: the old row under the write.
    reg [DB-1:0] z_pdata;
    always @(*) begin
        for (integer j = 0; j < BYTES; ++j)
            z_pdata[j*8 +: 8] = (z_merge & z_wmask[j / GROUP]) ? z_wdata[j*8 +: 8] : c_cb[j*8 +: 8];
    end

    reg              r_local, r_rd, r_ub, r_pin, r_fill;
    reg [LW-1:0]     r_rlin;
    reg [PW-1:0]     r_pinid;
    reg [1:0]        r_src;
    reg [QW-1:0]     r_slot, r_ubslot;
    reg [SEQ_W-1:0]  r_dseq;
    // The write it depends on had no B by Z; Z's B, if any.
    reg              r_dv, r_bpop;
    reg [SEQ_W-1:0]  r_bseq;
    reg [IT-1:0]     r_inst;
    reg [63:0]       r_addr;
    reg [DB-1:0]     r_pdata;

    always @(posedge clk) begin
        r_local  <= z_local & ~reset;
        r_rd     <= z_rd & ~z_local & ~reset;
        r_dseq   <= z_dseq;
        r_dv     <= z_buf | z_hzdep;
        r_bpop   <= b_pop;
        r_bseq   <= b_seq;
        r_ub     <= z_ub;
        r_pin    <= z_pin;
        r_pinid  <= z_pinid;
        r_fill   <= z_fill;
        r_rlin   <= z_rlin;
        r_src    <= z_src;
        r_slot   <= z_slot;
        r_ubslot <= wb_tail;
        r_inst   <= z_rinst;
        r_addr   <= z_raddr;
        r_pdata  <= z_pdata;
    end

    // ---- R: answer locally, or queue for AR ----

    reg [63:0]       rq_addr  [QUEUE];
    reg [IT-1:0]     rq_inst  [QUEUE];
    reg              rq_ub    [QUEUE];
    reg [QW-1:0]     rq_ubslot [QUEUE];
    reg [SEQ_W-1:0]  rq_dseq  [QUEUE];
    reg              rq_pin   [QUEUE];
    reg              rq_fill  [QUEUE];
    reg [LW-1:0]     rq_lin   [QUEUE];
    reg [PW-1:0]     rq_pinid [QUEUE];
    reg [QUEUE-1:0]  rq_dep;
    reg [QW-1:0]     rq_head, rq_tail;
    reg [FW-1:0]     rq_count;

    wire rq_push = r_rd;
    // A write in the buffer at Y has its B at R at the earliest (after its
    // last W beat is taken); the table's had none by Y. Their B's at Z and R.
    wire r_dep   = r_dv & ~(r_bpop & (r_bseq == r_dseq)) & ~(b_pop & (b_seq == r_dseq));

    // ---- AR: the read queue's head, on the next id while its ring has room ----
    wire          id_avail = (id_cnt[ar_rr] != (DPW+1)'(DEPTH));
    wire [OW-1:0] id_next  = tag_of(id_tail[ar_rr], ar_rr);
    wire          rq_issue = (rq_count != 0) & ~rq_dep[rq_head] & id_avail
                           & (~m_arvalid | m_arready) & ~reset;

    // The reads in flight, by tag: one memory of OUTSTANDING entries, written
    // at a read's issue (its tag, id_next) and read at its answer (rc_tag),
    // one write port and one asynchronous read, in an always block of its
    // own, so that every tool maps it as a memory (distributed RAM), at any
    // OUTSTANDING (foldsim --hbm-round-trip sizes it from the round trip).
    localparam TBLW = IT + SLW + 1 + QW + 1 + 1 + LW + PW;
    reg [TBLW-1:0] tbl [OUTSTANDING];
    wire [TBLW-1:0] tbl_in = {rq_inst[rq_head], SLW'(rq_addr[rq_head] >> RB), rq_ub[rq_head],
                              rq_ubslot[rq_head], rq_pin[rq_head], rq_fill[rq_head], rq_lin[rq_head],
                              rq_pinid[rq_head]};
    always @(posedge clk)
        if (rq_issue)
            tbl[id_next] <= tbl_in;

    always @(posedge clk) begin
        if (rq_push) begin
            rq_addr[rq_tail]   <= r_addr;
            rq_inst[rq_tail]   <= r_inst;
            rq_ub[rq_tail]     <= r_ub;
            rq_ubslot[rq_tail] <= r_ubslot;
            rq_dseq[rq_tail]   <= r_dseq;
            rq_pin[rq_tail]    <= r_pin;
            rq_fill[rq_tail]   <= r_fill;
            rq_lin[rq_tail]    <= r_rlin;
            rq_pinid[rq_tail]  <= r_pinid;
        end
        // A queued read waits for the B of the write it depends on.
        for (integer i = 0; i < QUEUE; ++i)
            if (b_pop & (rq_dseq[i][DSW-1:0] == b_seq[DSW-1:0]))
                rq_dep[i] <= 1'b0;
        if (rq_push)
            rq_dep[rq_tail] <= r_dep;
        if (reset) begin
            rq_head  <= '0;
            rq_tail  <= '0;
            rq_count <= '0;
        end else begin
            if (rq_push)
                rq_tail <= qinc(rq_tail);
            if (rq_issue)
                rq_head <= qinc(rq_head);
            rq_count <= rq_count + FW'(rq_push) - FW'(rq_issue);
        end
        if (rq_issue) begin
            // A row of a shared line: the line is read, the row's place kept.
            m_araddr            <= (SUB != 0) ? {rq_addr[rq_head][63:6], 6'd0} : rq_addr[rq_head];
            m_arid              <= AXI_ID_W'(ar_rr);
        end
        if (rq_issue)
            m_arvalid <= 1'b1;
        else if (m_arready)
            m_arvalid <= 1'b0;
    end
    assign m_arlen = 8'(BEATS - 1);

    // ---- R: beats by id (one burst of an id at a time), the last one
    // answers its id's oldest read ----
    reg [IDW-1:0] rc_id;
    // The read a beat answers: its slot of the tables, {its id's oldest, id},
    // found as the beat is taken (the oldest moves on if this cycle's beat
    // ends that id's burst), so the tables are read from a register.
    reg [OW-1:0]  rc_tag;
    // (The read's entry of the tag table, at its answer.)
    wire [TBLW-1:0] tbl_rd = tbl[rc_tag];
    wire [IT-1:0]  tbl_rc_inst;
    wire [SLW-1:0] tbl_rc_off;
    wire           tbl_rc_ub;
    wire [QW-1:0]  tbl_rc_ubslot;
    wire           tbl_rc_pin;
    wire           tbl_rc_fill;
    wire [LW-1:0]  tbl_rc_lin;
    wire [PW-1:0]  tbl_rc_pinid;
    assign {tbl_rc_inst, tbl_rc_off, tbl_rc_ub, tbl_rc_ubslot, tbl_rc_pin, tbl_rc_fill, tbl_rc_lin,
            tbl_rc_pinid} = tbl_rd;
    wire [IDW-1:0] r_inid = IDW'(m_rid);
    reg [511:0]   rc_data;
    /* verilator lint_off UNUSEDSIGNAL */
    reg           rc_rlast;
    /* verilator lint_on UNUSEDSIGNAL */
    always @(posedge clk) begin
        rc_valid <= m_rvalid & m_rready;
        rc_id    <= r_inid;
        rc_data  <= m_rdata;
        rc_rlast <= m_rlast;
    end
    reg  [BW-1:0] rcnt [NID];
`ifdef SIMULATION
    initial begin
        for (integer i = 0; i < NID; ++i)
            rcnt[i] = '0;
    end
`endif
    wire [BW-1:0] rc_beat = rcnt[rc_id];
    wire          rc_last = (rc_beat == BW'(BEATS - 1));
    wire          rc_done = rc_valid & rc_last;
    always @(posedge clk)
        rc_tag <= tag_of(id_head[r_inid] + DPW'(rc_done & (rc_id == r_inid)), r_inid);

    // The last beat's bits past the row are padding; a row of a shared line
    // is its part of the beat.
    /* verilator lint_off UNUSEDSIGNAL */
    wire [BEATS*512-1:0] rc_row;
    /* verilator lint_on UNUSEDSIGNAL */
    if (BEATS > 1 && DIRECT) begin : g_no_beats
        // (DIRECT: the beats go straight into the answer, g_direct_r.)
        assign rc_row[(BEATS-1)*512-1:0] = '0;
    end
    if (BEATS > 1 && !DIRECT) begin : g_beats
        for (genvar k = 0; k < BEATS - 1; ++k) begin : g_bm
            reg [511:0] bm [NID];
            always @(posedge clk)
                if (rc_valid & (rc_beat == BW'(k)))
                    bm[rc_id] <= rc_data;
            assign rc_row[k*512 +: 512] = bm[rc_id];
        end
    end
    if (SUB != 0) begin : g_sub_r
        wire [SLW-1:0] off = tbl_rc_off;
        assign rc_row = 512'(rc_data[32'(off) * (ROW_BYTES * 8) +: ROW_BYTES * 8]);
    end else begin : g_line_r
        /* verilator lint_off UNUSEDSIGNAL */
        wire unused = |tbl_rc_off;
        /* verilator lint_on UNUSEDSIGNAL */
        assign rc_row[(BEATS-1)*512 +: 512] = rc_data;
    end

    // A burst's beats are counted per id; the count is back at 0 after its
    // last.
    always @(posedge clk) begin
        if (rc_valid)
            rcnt[rc_id] <= rc_last ? '0 : rc_beat + 1'b1;
    end

    // ---- Responses: local (R) or from memory ----
    // None is offered while reset is high, not even one made before it.
    reg          rsp_q;
    reg [DB-1:0] rsp_row;
    assign rsp_valid = rsp_q & ~reset;
    // A row's bits above DW are zero (written so), never answered.
    // (DIRECT: the row its beats were written into.)
    wire [DW-1:0] d_data;
    assign rsp_data  = DIRECT ? d_data : rsp_row[DW-1:0];
    if (DIRECT) begin : g_direct_r
        /* verilator lint_off UNUSEDSIGNAL */
        reg [BEATS*512-1:0] d_row;
        /* verilator lint_on UNUSEDSIGNAL */
        assign d_data = d_row[DW-1:0];
        // One id: a burst's beats come in order, not interleaved with
        // another's; the last answers (rsp_q) as the row is whole, and the
        // next burst's first beat lands a cycle after the answer at the
        // earliest.
        for (genvar k = 0; k < BEATS; ++k) begin : g_beat
            always @(posedge clk)
                if (rc_valid & (rc_beat == BW'(k)))
                    d_row[k*512 +: 512] <= rc_data;
        end
    end else begin : g_no_direct_r
        assign d_data = '0;
    end
    if (DB > DW) begin : g_pad
        /* verilator lint_off UNUSEDSIGNAL */
        wire unused = |rsp_row[DB-1:DW];
        /* verilator lint_on UNUSEDSIGNAL */
    end
    always @(posedge clk) begin
        rsp_q <= (r_local | (rc_done & ~draining)) & ~reset;
        if (r_local) begin
            rsp_inst <= r_inst;
            case (r_src)
            // (Without a cache neither: the write's row is not staged to Z.)
            SRC_CA:  rsp_row <= (CACHE != 0) ? c_ca : '0;
            SRC_CB:  rsp_row <= (CACHE != 0) ? r_pdata : '0;
            SRC_ZR:  rsp_row <= '0;
            // Without forwarding no local answer comes from the buffer:
            // its second read port is not built.
            default: rsp_row <= (FORWARD != 0) ? wb_data[r_slot] : '0;
            endcase
        end else begin
            rsp_inst <= tbl_rc_inst;
            rsp_row  <= rc_row[DB-1:0];
        end
    end

    // The fill: the last answer from memory whose line may take it. Reset
    // and a move drop it, and no answer during the drain or the move fills.
    if (CACHE != 0) begin : g_fill
        reg          v;
        reg [LW-1:0] lin;
        reg [DB-1:0] data;
`ifdef SIMULATION
        initial v = 1'b0;
`endif
        always @(posedge clk) begin
            if (rc_done & tbl_rc_fill & ~draining & ~reset & ~mv_busy & ~move) begin
                v    <= 1'b1;
                lin  <= tbl_rc_lin;
                data <= rc_row[DB-1:0];
            end else if (reset | move | fill_go | (i_wr & (i_wlin == lin))) begin
                v    <= 1'b0;
            end
        end
        assign fl_v    = v;
        assign fl_lin  = lin;
        assign fl_data = data;
    end else begin : g_no_fill
        /* verilator lint_off UNUSEDSIGNAL */
        wire unused = tbl_rc_fill | (|tbl_rc_lin);
        /* verilator lint_on UNUSEDSIGNAL */
        assign fl_v    = 1'b0;
        assign fl_lin  = '0;
        assign fl_data = '0;
    end

    // ---- AW and W: the buffer's writes in order ----
    wire aw_issue = (n_aw != 0) & (~wb_blk[wb_aw] | draining) & (~m_awvalid | m_awready)
                  & (n_ab != NAW'(WRITES_OUT));
    wire w_issue  = (n_w != 0) & (~m_wvalid | m_wready);
    wire w_end    = w_issue & (w_beat == BW'(BEATS - 1));

    // A row of a shared line: in its every place of the beat, strobed in its
    // own.
    wire [BEATS*512-1:0] w_row;
    wire [BEATS*64-1:0]  w_strb;
    if (SUB != 0) begin : g_sub_w
        wire [SLW-1:0] off = SLW'(wb_addr[wb_w] >> RB);
        assign w_row  = {(64 / ROW_BYTES){(ROW_BYTES * 8)'(wb_data[wb_w])}};
        assign w_strb = 64'(byte_enables(wb_mask[wb_w])) << (32'(off) * ROW_BYTES);
    end else begin : g_line_w
        assign w_row  = (BEATS*512)'(wb_data[wb_w]);
        assign w_strb = (BEATS*64)'(byte_enables(wb_mask[wb_w]));
    end

    always @(posedge clk) begin
        if (aw_issue) begin
            m_awaddr <= (SUB != 0) ? {wb_addr[wb_aw][63:6], 6'd0} : wb_addr[wb_aw];
            wb_aw    <= qinc(wb_aw);
        end
        if (aw_issue)
            m_awvalid <= 1'b1;
        else if (m_awready)
            m_awvalid <= 1'b0;

        if (w_issue) begin
            m_wdata <= w_row[32'(w_beat) * 512 +: 512];
            m_wstrb <= w_strb[32'(w_beat) * 64 +: 64];
            m_wlast <= (w_beat == BW'(BEATS - 1));
            w_beat  <= (w_beat == BW'(BEATS - 1)) ? '0 : w_beat + 1'b1;
        end
        if (w_end)
            wb_w <= qinc(wb_w);
        if (w_issue)
            m_wvalid <= 1'b1;
        else if (m_wready)
            m_wvalid <= 1'b0;

        wb_cnt <= wb_cnt + FW'(z_alloc) - FW'(w_end);
        n_aw   <= n_aw + FW'(z_alloc) - FW'(aw_issue);
        n_w    <= n_w + FW'(aw_issue) - FW'(w_end);
        n_b    <= n_b + NAW'(w_end) - NAW'(b_pop);
        n_ab   <= n_ab + NAW'(aw_issue) - NAW'(b_pop);
        n_fl   <= n_fl + NFW'(z_alloc) - NFW'(b_pop);
        if (z_alloc)
            w_seq <= w_seq + 1'b1;
        if (b_pop)
            b_seq <= b_seq + 1'b1;
    end
    assign m_awid   = '0;
    assign m_awlen  = 8'(BEATS - 1);
    assign m_bready = 1'b1;

    // ---- The buffer's slots: taken at Z, freed by their last W beat ----
    always @(posedge clk) begin
        if (z_alloc) begin
            wb_lin[wb_tail]  <= z_alin;
            wb_seq[wb_tail]  <= w_seq;
            wb_addr[wb_tail] <= z_aaddr;
        end
        for (integer i = 0; i < QUEUE; ++i)
            if (z_alloc & whit[i])
                wb_live[i] <= 1'b0;
        if (z_alloc) begin
            wb_live[wb_tail] <= 1'b1;
            wb_full[wb_tail] <= z_afull;
            wb_tail          <= qinc(wb_tail);
        end
        // A write held for its own cycle's read goes once that read has its
        // data.
        if (r_local & r_ub)
            wb_blk[r_ubslot] <= 1'b0;
        if (rc_done & tbl_rc_ub)
            wb_blk[tbl_rc_ubslot] <= 1'b0;
        if (z_alloc)
            wb_blk[wb_tail] <= z_wa & z_blk;

        begin : valid_
            reg [QUEUE-1:0] v;
            v = wb_valid;
            if (w_end)
                v[wb_w] = 1'b0;
            if (z_alloc)
                v[wb_tail] = 1'b1;
            wb_valid <= v;
        end
    end

    // A row's data and mask: written at Z with its slot, or (no host cache) at
    // X. Without a cache every write takes a slot, in order, two cycles after
    // X (no fill, no eviction, none goes into a line): the write at X takes
    // the slot after those of the writes at Y and Z. That slot is free: a
    // write holds room from the cycle it is taken until its slot's last W
    // beat, room comes back a cycle late, and QUEUE bounds the room, so the
    // write QUEUE writes before it has left the slot before it was taken.
    // The row then waits in the buffer, not in two pipeline stages a row wide.
    if (CACHE != 0) begin : g_zdata
        always @(posedge clk)
            if (z_alloc) begin
                wb_data[wb_tail] <= z_adata;
                wb_mask[wb_tail] <= z_amask;
            end
    end else begin : g_xdata
        wire [QW-1:0] y_slot = z_alloc ? qinc(wb_tail) : wb_tail;
        wire [QW-1:0] x_slot = y_wr ? qinc(y_slot) : y_slot;
        if (KZ != 0) begin : g_at_x
            // (Known-zero rows: made whole at X.)
            always @(posedge clk)
                if (x_wr) begin
                    wb_data[x_slot] <= x_wzdata;
                    wb_mask[x_slot] <= x_wmask | {MW{kz_w}};
                end
        end else begin : g_at_i
            // (Nothing to make whole: the row goes in as it is taken.)
            wire [QW-1:0] i_slot = x_wr ? qinc(x_slot) : x_slot;
            always @(posedge clk)
                if (i_wr) begin
                    wb_data[i_slot] <= i_wdata;
                    wb_mask[i_slot] <= i_wmask;
                end
        end
`ifdef SIMULATION
        // (The claim above: the write at X takes x_slot at Z, and only it.)
        reg [QW-1:0] xs1, xs2;
        reg          xv1, xv2;
        initial begin
            xv1 = 1'b0;
            xv2 = 1'b0;
        end
        always @(posedge clk) begin
            xs1 <= x_slot;
            xs2 <= xs1;
            xv1 <= x_wr;
            xv2 <= xv1;
            if ((xv2 != z_alloc) | (z_alloc & (xs2 != wb_tail)))
                $error("foldsim_vmem: a cache-less write's slot at X is not its slot at Z");
        end
`endif
    end

    // ---- Ids: each a ring of its reads, from AR until the last beat of R ----
    always @(posedge clk) begin
        for (integer i = 0; i < NID; ++i)
            id_cnt[i] <= id_cnt[i] + (DPW+1)'(rq_issue & (ar_rr == IDW'(i)))
                                   - (DPW+1)'(rc_done & (rc_id == IDW'(i)));
        if (rq_issue) begin
            id_tail[ar_rr] <= id_tail[ar_rr] + 1'b1;
            ar_rr          <= (ar_rr == IDW'(NID - 1)) ? '0 : ar_rr + 1'b1;
        end
        if (rc_done)
            id_head[rc_id] <= id_head[rc_id] + 1'b1;
        rd_out <= rd_out + (OW+1)'(rq_issue) - (OW+1)'(rc_done);
    end

    // ---- Pins: a shared line held for its read-first pair's read ----
    // Released when the read has its data (one answer a cycle at most). A
    // reset drops them all: no read from before it answers.
    wire          pin_rel   = (r_local & r_pin) | (rc_done & tbl_rc_pin);
    wire [PW-1:0] pin_relid = r_local ? r_pinid : tbl_rc_pinid;

    if (PIN) begin : g_pin
        reg [PINS-1:0] pin_v;
        reg [CI-1:0]   pin_idx [PINS];
        reg            pinned_q;
        wire [CI-1:0]  x_idx = cidx(x_wlin);
        reg  [PINS-1:0] pm;
        always @(*) begin
            for (integer i = 0; i < PINS; ++i)
                pm[i] = pin_v[i] & (pin_idx[i] == x_idx);
        end
        always @(posedge clk) begin
            // A pair at Y may pin X's line this cycle: taken as pinned.
            pinned_q <= (|pm) | (rf_pair & y_wfull & (cidx(y_wlin) == x_idx));
            if (y_pin)
                pin_idx[pin_next] <= cidx(y_wlin);
            begin : v_
                reg [PINS-1:0] v;
                v = pin_v;
                if (pin_rel)
                    v[pin_relid] = 1'b0;
                if (y_pin)
                    v[pin_next] = 1'b1;
                pin_v <= reset ? '0 : v;
            end
        end
        reg [PW-1:0] nx;
        always @(*) begin
            nx = '0;
            for (integer i = PINS - 1; i >= 0; --i)
                if (!pin_v[i])
                    nx = PW'(i);
        end
`ifdef SIMULATION
        always @(posedge clk) begin
            for (integer i = 0; i < PINS; ++i)
                if (evict & pin_v[i] & (pin_idx[i] == y_widx))
                    $error("foldsim_vmem: pinned line %0d evicted", y_widx);
        end
`endif
        assign y_pinned = pinned_q;
        assign pin_room = ~(&pin_v);
        assign pin_next = nx;
    end else begin : g_no_pin
        /* verilator lint_off UNUSEDSIGNAL */
        wire unused = pin_rel | (|pin_relid);
        /* verilator lint_on UNUSEDSIGNAL */
        assign y_pinned = 1'b0;
        assign pin_room = 1'b1;
        assign pin_next = '0;
    end

    // ---- The host cache ----
    if (CACHE != 0) begin : g_cache
        // A line: valid, dirty (the write's lookup only), tag. Writes leave a
        // line dirty, fills clean. Two copies of the tags, one per lookup;
        // each is read at X, and the update of the cycle before (made at Y as
        // the read was made) is forwarded. Whether it is at X's lines, and its
        // tag X's, is known at X.
        localparam TE = CT + 1;
        localparam TW = CT + 2;
        reg [TE-1:0] tag_r [CACHE_ROWS];
        reg [TW-1:0] tag_w [CACHE_ROWS];
        reg [TE-1:0] tr_q;
        reg [TW-1:0] tw_q, tu_ent;
        reg          tu_v, selr_q, selw_q, bhr_q, bhw_q;
`ifdef SIMULATION
        initial begin
            for (integer i = 0; i < CACHE_ROWS; ++i) begin
                tag_r[i] = '0;
                tag_w[i] = '0;
            end
        end
`endif
        wire [CI-1:0] y_ridx = cidx(y_rlin);
        wire [CI-1:0] x_ridx = cidx(x_rlin);
        wire [CI-1:0] x_widx = x_sw ? x_swidx : cidx(x_wlin);
        wire          tu_we  = c_whit | w_alloc | f_alloc | y_sw;
        wire [TW-1:0] tu_new = y_sw ? '0 : {1'b1, y_wr, CT'(y_wlin >> CI)};

        always @(posedge clk) begin
            tr_q <= tag_r[x_ridx];
            tw_q <= tag_w[x_widx];
            if (tu_we) begin
                tag_r[y_widx] <= {tu_new[TW-1], tu_new[CT-1:0]};
                tag_w[y_widx] <= tu_new;
            end
            tu_v   <= tu_we;
            tu_ent <= tu_new;
            selr_q <= (y_wr | y_sw | y_fl) & (y_widx == x_ridx);
            selw_q <= (y_wr | y_sw | y_fl) & (y_widx == x_widx);
            bhr_q  <= ~y_sw & (CT'(y_wlin >> CI) == CT'(x_rlin >> CI));
            bhw_q  <= ~y_sw & (CT'(y_wlin >> CI) == CT'(x_wlin >> CI));
        end
        wire br = selr_q & tu_v;
        wire bw = selw_q & tu_v;

        assign c_rhit     = y_rd & (br ? bhr_q : (tr_q[TE-1] & (tr_q[CT-1:0] == CT'(y_rlin >> CI))));
        assign c_whit     = y_wr & (bw ? bhw_q : (tw_q[TW-1] & (tw_q[CT-1:0] == CT'(y_wlin >> CI))));
        assign c_victim   = bw ? tu_ent[TW-2] : tw_q[TW-2];
        assign c_vtag     = bw ? tu_ent[CT-1:0] : tw_q[CT-1:0];
        assign c_same_idx = (y_ridx == y_widx);

        // The rows: port A reads for the read (two cycles: an output
        // register); port B writes for the write, reading first the line it
        // replaces or the read of its cycle shares.
        reg [DB-1:0] cdata [CACHE_ROWS];
        reg [DB-1:0] ca1, ca2, cb1;
        // An allocation's mask is whole: the enables are the write's own,
        // apart from whether it writes the line at all.
        wire             cwe = c_whit | w_alloc | f_alloc;
        wire [BYTES-1:0] be  = byte_enables(y_wmask);
        always @(posedge clk) begin
            ca1 <= cdata[y_ridx];
            ca2 <= ca1;
        end
        always @(posedge clk) begin
            cb1 <= cdata[y_widx];
            if (cwe) begin
                for (integer j = 0; j < BYTES; ++j)
                    if (be[j])
                        cdata[y_widx][j*8 +: 8] <= y_wdata[j*8 +: 8];
            end
        end
        assign c_ca = ca2;
        assign c_cb = cb1;
    end else begin : g_direct
        assign c_rhit     = 1'b0;
        assign c_whit     = 1'b0;
        assign c_victim   = 1'b0;
        assign c_vtag     = '0;
        assign c_same_idx = 1'b0;
        assign c_ca       = '0;
        assign c_cb       = '0;
    end

    // ---- Known-zero rows: written since the reset ----
    // Row lin's bit is bit lin / KBANKS of bank lin % KBANKS. A write sets
    // its row's bit as it is taken, reading the bit first; a read reads its
    // row's bit as it is taken, so it sees every earlier write's, but not a
    // same-cycle one's (a pair's read takes its write's old bit). A later
    // write of its row comes only after its answer (guarantee 4). The reset
    // clears a word of every bank a cycle in its drain, which takes no
    // request; a write taken before it and still in the multiply then sets
    // nothing, as the reset forgets it anyway.
    if (KZ != 0) begin : g_kz
        // Bits, a block of 2^KZ_SHIFT rows each; bit b is word b / KBANKS of
        // bank b % KBANKS.
        localparam KLW    = LW - KZ_SHIFT;
        localparam KROWS  = int'(((64'd1 << AW) * 64'(INSTANCES) + (64'd1 << KZ_SHIFT) - 1) >> KZ_SHIFT);
        localparam KBB    = (KLW < 4) ? KLW : 4;
        localparam KBANKS = 1 << KBB;
        localparam KDEPTH = (KROWS + KBANKS - 1) / KBANKS;
        localparam KAW    = (KDEPTH > 1) ? $clog2(KDEPTH) : 1;
        reg              zv, done, looked;
        reg [KAW-1:0]    ptr;
        wire [KLW-1:0]   wblk  = KLW'(i_wlin >> KZ_SHIFT);
        wire [KLW-1:0]   rblk  = KLW'(i_rlin >> KZ_SHIFT);
        wire             clear = (draining | mv_flush) & ~reset & ~done;
        wire             set   = i_wr & ~reset & ~draining;
        wire [KAW-1:0]   wa    = clear ? ptr : KAW'(wblk >> KBB);
        wire [KAW-1:0]   ra    = KAW'(rblk >> KBB);
        wire [KBANKS-1:0] wq, rq;
        for (genvar b = 0; b < KBANKS; ++b) begin : g_bank
            reg mem [KDEPTH];
            reg wo, ro;
            always @(posedge clk) begin
                wo <= mem[wa];
                ro <= mem[ra];
                if (clear | (set & (wblk[KBB-1:0] == KBB'(b))))
                    mem[wa] <= ~clear;
            end
            assign wq[b] = wo;
            assign rq[b] = ro;
        end
        always @(posedge clk) begin
            zv     <= zero & ~reset;
            looked <= set;
            if (reset | mv_go) begin
                ptr  <= '0;
                done <= 1'b0;
            end else if (clear) begin
                ptr <= ptr + 1'b1;
                if (ptr == KAW'(KDEPTH - 1))
                    done <= 1'b1;
            end
        end
        assign kz_w    = looked & zv & ~wq[KBB'(x_wlin >> KZ_SHIFT)];
        assign kz_r    = zv & ~rq[KBB'(x_rlin >> KZ_SHIFT)];
        assign kz_done = done;
    end else begin : g_no_kz
        /* verilator lint_off UNUSEDSIGNAL */
        wire unused = zero;
        /* verilator lint_on UNUSEDSIGNAL */
        assign kz_w    = 1'b0;
        assign kz_r    = 1'b0;
        assign kz_done = 1'b1;
    end

    // The sweep of a reset's drain or a move's flush: a line per cycle while
    // the buffer has room for what is in flight, once the writes taken before
    // it are in.
    assign sweep_go = (CACHE != 0) & (draining | mv_flush) & ~reset & ~sw_done & ~i_busy & ~x_wr & ~y_wr
                    & ~x_fl & ~y_fl & (wb_cnt <= FW'(QUEUE - 4));
    always @(posedge clk) begin
        if (reset | mv_go) begin
            sw_done <= (CACHE == 0);
            sw_idx  <= '0;
        end else if (sweep_go) begin
            sw_idx <= sw_idx + 1'b1;
            if (sw_idx == CI'(CACHE_ROWS - 1))
                sw_done <= 1'b1;
        end
    end

    // ---- Room, and the drain after a reset ----
    wire idle = sw_done & kz_done & ~i_busy & ~x_wr & ~y_wr & ~x_sw & ~y_sw & ~x_fl & ~y_fl & ~z_alloc
              & (n_fl == '0) & (rd_out == '0)
              & ~m_arvalid & ~m_awvalid & ~m_wvalid & ~rc_valid;

    // ---- A move: serve what was taken, then the flush ----
    // Nothing taken is in flight but writes in the buffer: no read anywhere,
    // no write still to look up its known-zero bit or reach the cache.
    wire quiet = ~i_busy & ~i_rbusy & ~x_rd & ~y_rd & ~z_rd & ~r_rd & ~r_local & (rq_count == '0)
               & (rd_out == '0) & ~rc_valid & ~x_wr & ~y_wr;
    reg  [3:0] mv_cnt;
    wire       mv_start = move & ~mv_busy & ~reset & ~draining;
    assign     mv_go    = mv_busy & ~mv_flush & quiet & (mv_cnt == 4'(QUIET));
    wire       mv_end   = mv_flush & idle;
    always @(posedge clk) begin
        if (reset) begin
            mv_busy  <= 1'b0;
            mv_flush <= 1'b0;
        end else begin
            if (mv_start)
                mv_busy <= 1'b1;
            else if (mv_end)
                mv_busy <= 1'b0;
            if (mv_go)
                mv_flush <= 1'b1;
            else if (mv_end)
                mv_flush <= 1'b0;
        end
        // Cycles since the last request (QUIET at most).
        if (mv_start | rd_valid | wr_valid)
            mv_cnt <= '0;
        else if (mv_cnt != 4'(QUIET))
            mv_cnt <= mv_cnt + 1'b1;
    end
    assign moving    = mv_busy;
    assign base_hold = reset | (draining & ~idle) | (mv_busy & ~mv_end) | move;

    // Room given back counts a cycle late: free only rises later. room counts
    // requests and their room until a move's flush too (free shows 0 from the
    // move); the flush, as the drain, ends with everything back.
    reg  [2:0]    rel_q;
    reg  [FW-1:0] room;
    // Outside reset and its drain, every request is taken.
    wire [3:0]    delta  = {1'b0, rel_q} - 4'(rd_valid) - 4'(wr_valid);
    wire [FW-1:0] room_n = reset ? '0
                         : (draining | mv_flush) ? (idle ? FW'(QUEUE) : '0)
                         : room + FW'($signed(delta));

    always @(posedge clk) begin
        rel_q <= (reset | draining | mv_flush) ? 3'd0
               : 3'(r_local) + 3'(rq_issue) + 3'(w_end) + 3'(y_wdone);
        if (reset)
            draining <= 1'b1;
        else if (draining & idle)
            draining <= 1'b0;
        room <= room_n;
        if (mv_start | (mv_busy & ~mv_end))
            free <= '0;
        else
            free <= room_n;
    end

    // ---- Telemetry ----
    // Each event registered first, then counted: the counters add no logic
    // to the controller's paths, and read a cycle late.
    if (TELEMETRY != 0) begin : g_tel
        reg [TEL_N-1:0] ev;
        reg [TEL_W-1:0] cnt [TEL_N];
        always @(posedge clk) begin
            ev <= {(rd_out != '0), (free == '0), (m_awvalid & m_awready), (m_arvalid & m_arready),
                   r_local, taken_wr, taken_rd} & {TEL_N{~reset}};
            for (integer c = 0; c < TEL_N; ++c) begin
                if (reset)
                    cnt[c] <= '0;
                else if (ev[c])
                    cnt[c] <= cnt[c] + 1'b1;
            end
        end
        for (genvar c = 0; c < TEL_N; ++c) begin : g_out
            assign tel[c * TEL_W +: TEL_W] = cnt[c];
        end
    end else begin : g_no_tel
        assign tel = '0;
    end

`ifdef SIMULATION
    // The simulator's guarantees, and the protocol memory must keep.
    reg sim_pending [1 << IT];
    always @(posedge clk) begin
        if (reset) begin
            for (integer i = 0; i < (1 << IT); ++i)
                sim_pending[i] <= 1'b0;
        end else begin
            if ((rd_valid && 32'(rd_inst[IW-1:0]) >= INSTANCES) || (wr_valid && 32'(wr_inst[IW-1:0]) >= INSTANCES))
                $error("foldsim_vmem: an instance index past INSTANCES");
            if ((FW+1)'(rd_valid) + (FW+1)'(wr_valid) > (FW+1)'(room))
                $error("foldsim_vmem: a request without room (%0d)", room);
            if ((rd_valid | wr_valid) & mv_flush)
                $error("foldsim_vmem: a request in a move's flush, QUIET cycles after free dropped to 0");
            if (rd_valid & sim_pending[rd_inst])
                $error("foldsim_vmem: a second read of instance %0d outstanding", rd_inst);
            if (wr_valid & sim_pending[wr_inst])
                $error("foldsim_vmem: a write of instance %0d, whose read is outstanding", wr_inst);
            if (rsp_valid)
                sim_pending[rsp_inst] <= 1'b0;
            if (taken_rd)
                sim_pending[rd_inst] <= 1'b1;
        end
        if ((m_rvalid & m_rready) && (32'(m_rid) >= NID || id_cnt[IDW'(m_rid)] == '0))
            $error("foldsim_vmem: R for id %0d, which has no read", m_rid);
        if (rc_valid && (rc_rlast != rc_last))
            $error("foldsim_vmem: R's last beat out of place for id %0d", rc_id);
        if (m_bvalid & ((n_b == 0) | (m_bid != '0)))
            $error("foldsim_vmem: B with no write, or of id %0d", m_bid);
        if (aw_issue & (n_ab == NAW'(WRITES_OUT)))
            $error("foldsim_vmem: more than WRITES_OUT writes on AXI");
        if (r_local & rc_done)
            $error("foldsim_vmem: two responses in one cycle");
        if (z_alloc & (wb_cnt == FW'(QUEUE)) & ~w_end)
            $error("foldsim_vmem: the write buffer overflows");
        if (z_alloc & (n_fl == NFW'(QUEUE + WRITES_OUT)) & ~b_pop)
            $error("foldsim_vmem: more writes without a B than numbers kept");
        if ((base_q & ((64'd1 << RB) - 1)) != 0)
            $error("foldsim_vmem: base not aligned to a row");
    end
`endif

endmodule
